"""Streamlit demo: replay the held-out period through the live scoring path and watch the business outcome.

    streamlit run demo/app.py
"""
import sys
import time
from pathlib import Path

import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from sentinel.serve.online import OnlineFeaturizer
from sentinel.serve.scorer import Scorer
from sentinel.serve.state import InMemoryStore
from sentinel.serve.warm import row_to_txn, warm_store

ART = ROOT / "artifacts"
st.set_page_config(page_title="Sentinel", page_icon="🛡️", layout="wide")


@st.cache_resource(show_spinner="Loading model and warming card history ...")
def boot():
    sc = Scorer(ART / "bundle.joblib")
    rp = pd.read_csv(ART / "replay.csv.gz")
    fz = OnlineFeaturizer(InMemoryStore(), sc.vocab)
    warm_store(fz, rp[rp.phase == "warm"])
    return sc, fz, rp[rp.phase == "test"].reset_index(drop=True)


def init_state():
    st.session_state.setdefault("pos", 0)
    st.session_state.setdefault("log", [])


sc, fz, test = boot()
cm = sc.bundle["cost_model"]
init_state()

st.title("Sentinel")
st.caption(f"Real-time fraud decisions on held-out transactions · model {sc.version} · "
           f"data: {sc.bundle['metadata']['data']}")
c1, c2, c3 = st.columns([1, 1, 3])
batch = c1.slider("Transactions per click", 50, 1000, 250, 50)
if c2.button("▶ Replay next batch", type="primary"):
    t0 = time.time()
    for r in test.iloc[st.session_state.pos: st.session_state.pos + batch].to_dict("records"):
        t = row_to_txn(r); f = fz.features(t); res = sc.score(f); fz.commit(t)
        st.session_state.log.append({"ts": t["ts"], "card": t["card_id"], "amount": t["amount"], "fraud": int(r["is_fraud"]),
                                     "decision": res["decision"], "risk": res["risk"],
                                     "why": "; ".join(x["detail"] for x in res["reasons"])})
    st.session_state.pos += batch
if c3.button("↺ Reset"):
    st.session_state.pos, st.session_state.log = 0, []
    st.cache_resource.clear(); st.rerun()

L = pd.DataFrame(st.session_state.log)
if L.empty:
    st.info("Press **Replay next batch** to stream transactions through the model.")
    st.stop()

fraud = L.fraud == 1
approve, review, decline = (L.decision == x for x in ("approve", "review", "decline"))
missed = L.amount[fraud & approve].sum() + (1 - cm["review_catch_rate"]) * L.amount[fraud & review].sum()
cost = missed + cm["decline_cost"] * (~fraud & decline).sum() + cm["review_cost"] * review.sum()
base = L.amount[fraud].sum()
m = st.columns(5)
m[0].metric("Scored", f"{len(L):,}")
m[1].metric("Fraud in stream", int(fraud.sum()))
m[2].metric("Flagged (review+decline)", int((~approve).sum()))
m[3].metric("Cost if we approved all", f"${base:,.0f}")
m[4].metric("Cost with Sentinel", f"${cost:,.0f}", delta=f"{(cost - base) / max(base, 1):.0%}", delta_color="inverse")

L["cum_cost_sentinel"] = (L.amount.where(fraud & approve, 0) + (1 - cm["review_catch_rate"]) * L.amount.where(fraud & review, 0)
                          + cm["decline_cost"] * (~fraud & decline) + cm["review_cost"] * review).cumsum()
L["cum_cost_approve_all"] = L.amount.where(fraud, 0).cumsum()
st.line_chart(L[["cum_cost_approve_all", "cum_cost_sentinel"]], height=260)

st.subheader("Latest flagged transactions")
flag = L[~approve].tail(25).iloc[::-1]
st.dataframe(flag[["card", "amount", "decision", "risk", "fraud", "why"]].assign(risk=flag.risk.round(3)),
             width="stretch", hide_index=True)
