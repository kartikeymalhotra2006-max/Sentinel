"""Load test:  locust -f scripts/locustfile.py --host http://127.0.0.1:8000"""
import random
from locust import HttpUser, between, task


class Shopper(HttpUser):
    wait_time = between(0.01, 0.1)
    ts = 1_700_000_000

    @task
    def score(self):
        Shopper.ts += random.randint(1, 30)
        self.client.post("/score", json={"ts": Shopper.ts, "card_id": f"c{random.randint(1, 5000)}",
                                         "amount": round(random.lognormvariate(3.5, 0.8), 2), "device_id": f"d{random.randint(1, 9000)}",
                                         "product": random.choice("WCHRS"), "email_domain": "gmail.com", "device_type": "mobile"})
