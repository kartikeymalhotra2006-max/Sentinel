"""Replay the held-out test period against a *running* API and report realised business outcome.

    uvicorn sentinel.serve.app:app &           # SENTINEL_BUNDLE=artifacts/bundle.joblib
    python scripts/replay.py --url http://127.0.0.1:8000 -n 3000
The server state is warmed first with the 'warm' history via POST /ingest (no scoring, no drift stats).
"""
import argparse
import json
import sys
from pathlib import Path

import httpx
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from sentinel.serve.warm import row_to_txn


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://127.0.0.1:8000"); ap.add_argument("--artifacts", default="artifacts")
    ap.add_argument("-n", type=int, default=3000); ap.add_argument("--warm-rows", type=int, default=0, help="0 = all history")
    a = ap.parse_args()
    rp = pd.read_csv(Path(a.artifacts) / "replay.csv.gz")
    warm, test = rp[rp.phase == "warm"], rp[rp.phase == "test"].head(a.n)
    if a.warm_rows: warm = warm.tail(a.warm_rows)
    cm = httpx.get(f"{a.url}/model").json()["cost_model"]
    with httpx.Client(base_url=a.url, timeout=10) as c:
        print(f"warming state with {len(warm):,} historical transactions ...")
        rows = [row_to_txn(r) for r in warm.to_dict("records")]
        for i in range(0, len(rows), 2000):
            c.post("/ingest", json={"txns": rows[i:i + 2000]}).raise_for_status()
        dec, lat = [], []
        for r in test.to_dict("records"):
            j = c.post("/score", json=row_to_txn(r)).json(); dec.append(j["decision"]); lat.append(j["latency_ms"])
    test = test.assign(decision=dec)
    fr, amt = test.is_fraud == 1, test.amount
    app_, rev, dcl = test.decision == "approve", test.decision == "review", test.decision == "decline"
    missed = amt[fr & app_].sum() + (1 - cm["review_catch_rate"]) * amt[fr & rev].sum()
    cost = missed + cm["decline_cost"] * (~fr & dcl).sum() + cm["review_cost"] * rev.sum()
    print(json.dumps({"scored": len(test), "decisions": test.decision.value_counts().to_dict(),
                      "fraud_amount_total": float(amt[fr].sum()), "realised_cost": float(cost),
                      "approve_all_cost": float(amt[fr].sum()), "saving": float(1 - cost / max(amt[fr].sum(), 1e-9)),
                      "server_latency_ms_p95": float(np.percentile(lat, 95))}, indent=2))


if __name__ == "__main__":
    main()
