"""Measure scoring latency/throughput. Run after training:  python scripts/benchmark.py

Reports two layers so you can see where time goes:
  components  featurize + score + commit in-process (no HTTP)
  asgi        full FastAPI request path via the ASGI test client (no network hop)
For a true network benchmark run uvicorn and use `locust -f scripts/locustfile.py`.
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from fastapi.testclient import TestClient
from sentinel.serve.app import create_app
from sentinel.serve.online import OnlineFeaturizer
from sentinel.serve.scorer import Scorer
from sentinel.serve.state import InMemoryStore
from sentinel.serve.warm import row_to_txn, warm_store


def pct(a):
    a = np.asarray(a)
    return {"p50_ms": float(np.percentile(a, 50)), "p95_ms": float(np.percentile(a, 95)),
            "p99_ms": float(np.percentile(a, 99)), "mean_ms": float(a.mean())}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--artifacts", default="artifacts"); ap.add_argument("-n", type=int, default=2000)
    a = ap.parse_args()
    art = Path(a.artifacts)
    rp = pd.read_csv(art / "replay.csv.gz")
    warm, test = rp[rp.phase == "warm"], rp[rp.phase == "test"].head(a.n)
    txns = [row_to_txn(r) for r in test.to_dict("records")]

    sc = Scorer(art / "bundle.joblib")
    fz = OnlineFeaturizer(InMemoryStore(), sc.vocab)
    warm_store(fz, warm)
    lat = []
    for t in txns:
        t0 = time.perf_counter(); f = fz.features(t); sc.score(f); fz.commit(t); lat.append((time.perf_counter() - t0) * 1000)
    comp = {**pct(lat), "throughput_per_sec_single_core": float(1000 / np.mean(lat))}

    with TestClient(create_app(str(art / "bundle.joblib"), InMemoryStore())) as c:
        warm_store(c.app.state.featurizer, warm)
        lat2 = []
        for t in txns:
            t0 = time.perf_counter(); r = c.post("/score", json=t); lat2.append((time.perf_counter() - t0) * 1000); assert r.status_code == 200
    out = {"requests": len(txns), "components": comp, "asgi_end_to_end": pct(lat2),
           "note": "single shared CPU core in the build container; expect lower on dedicated hardware"}
    (art / "latency.json").write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
