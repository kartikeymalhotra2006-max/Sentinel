"""The Kaggle IEEE-CIS files can't be downloaded in CI, so we fabricate files with the *same schema*
(including NaN-heavy DeviceInfo / card2 / addr1) and push them through the loader and the full pipeline."""
from argparse import Namespace

import numpy as np
import pandas as pd

from sentinel.data.synth import generate
from sentinel.data.ieee import load_ieee
from sentinel.pipeline import run


def _write_ieee_files(folder, n=30_000, seed=3):
    df = generate(n_txn=n, n_cards=max(300, n // 21), seed=seed)
    rng = np.random.default_rng(0)
    cid = pd.factorize(df["card_id"])[0]
    tr = pd.DataFrame({"TransactionID": 2_987_000 + np.arange(len(df)), "isFraud": df["is_fraud"], "TransactionDT": df["ts"] + 86_400,
                       "TransactionAmt": df["amount"], "ProductCD": df["product"], "card1": 1000 + cid, "card2": np.where(rng.random(len(df)) < .02, np.nan, 111.0),
                       "addr1": np.where(rng.random(len(df)) < .1, np.nan, 300.0), "P_emaildomain": df["email_domain"].where(rng.random(len(df)) > .1)})
    has = rng.random(len(df)) < 0.35                                    # identity table only covers ~1/3 of rows
    idt = pd.DataFrame({"TransactionID": tr["TransactionID"][has], "DeviceType": df["device_type"][has],
                        "DeviceInfo": np.where(rng.random(has.sum()) < .2, np.nan, df["device_id"][has])})
    tr.to_csv(folder / "train_transaction.csv", index=False)
    idt.to_csv(folder / "train_identity.csv", index=False)
    return df


def test_loader_maps_to_canonical_schema(tmp_path):
    _write_ieee_files(tmp_path, n=3000)
    d = load_ieee(str(tmp_path))
    assert {"ts", "card_id", "amount", "device_id", "product", "email_domain", "device_type", "is_fraud"} <= set(d.columns)
    assert d["ts"].is_monotonic_increasing
    assert d["device_id"].isna().mean() > 0.5                           # most rows have no device, as in the real data


def test_full_pipeline_runs_on_ieee_schema(tmp_path):
    _write_ieee_files(tmp_path)
    out = tmp_path / "out"
    R = run(Namespace(data="ieee", ieee_dir=str(tmp_path), out=str(out), n_txn=0, seed=0, tune=0, boot=3,
                      decline_cost=15.0, review_cost=3.0, catch_rate=0.85, force_final="lightgbm"))
    assert R["meta"]["data"] == "ieee" and (out / "bundle.joblib").exists()
    assert not (out / "replay.csv.gz").exists()                          # never redistribute real data
    assert R["models"]["lightgbm"]["test"]["pr_auc"] > R["meta"]["fraud_rate"]


def test_missing_card_parts_do_not_create_null_card_ids(tmp_path):
    _write_ieee_files(tmp_path, n=3000)
    d = load_ieee(str(tmp_path))
    assert d["card_id"].notna().all()
    assert d["card_id"].str.contains("na").any()                         # the missing addr1/card2 rows are kept, labelled
