import pandas as pd

from sentinel.models import time_splits


def test_artifacts_exist(trained):
    out, _ = trained
    for f in ["bundle.joblib", "results.json", "results.md", "replay.csv.gz"]:
        assert (out / f).exists(), f
    for p in ["pr_curve", "cost_curve", "calibration", "shap_global", "ablation", "drift_weekly", "retrain"]:
        assert (out / "plots" / f"{p}.png").stat().st_size > 5_000


def test_splits_are_chronological_and_disjoint():
    sp = time_splits(1000)
    order = list(sp.values())
    assert order[0].start == 0 and order[-1].stop == 1000
    for a, b in zip(order[:-1], order[1:]):
        assert a.stop == b.start


def test_model_beats_baselines(trained):
    _, R = trained
    m = R["models"]
    assert m["lightgbm"]["test"]["pr_auc"] > R["meta"]["fraud_rate"] * 3          # far above no-skill
    assert m["lightgbm"]["test_cost"]["total"] < R["approve_all_cost"]["test"]    # saves money vs approving all
    assert R["models"]["lightgbm"]["thresholds"]["review"] <= R["models"]["lightgbm"]["thresholds"]["decline"]


def test_replay_file_matches_schema(trained):
    out, _ = trained
    rp = pd.read_csv(out / "replay.csv.gz")
    assert set(rp["phase"]) == {"warm", "test"} and rp["ts"].is_monotonic_increasing
