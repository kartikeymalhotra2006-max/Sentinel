"""Proves features never use the future or the label."""
import numpy as np
import pytest

from sentinel.features import build_features, fit_vocab


def _eq(a, b):
    np.testing.assert_allclose(a.to_numpy(float), b.to_numpy(float), rtol=1e-9, atol=1e-9, equal_nan=True)


def test_truncating_the_future_does_not_change_past_features(small_df):
    v = fit_vocab(small_df)
    full = build_features(small_df, v)
    k = 3000
    part = build_features(small_df.iloc[:k].copy(), v)
    _eq(full.iloc[:k], part)


def test_perturbing_future_rows_does_not_change_past_features(small_df):
    v = fit_vocab(small_df)
    k = 3000
    base = build_features(small_df, v).iloc[:k]
    d2 = small_df.copy()
    rng = np.random.default_rng(0)
    d2.loc[d2.index[k:], "amount"] = rng.uniform(1, 9999, len(d2) - k)
    d2.loc[d2.index[k:], "device_id"] = "zzz"
    d2.loc[d2.index[k:], "card_id"] = rng.choice(small_df["card_id"].unique(), len(d2) - k)
    _eq(base, build_features(d2, v).iloc[:k])


def test_labels_are_never_used(small_df):
    v = fit_vocab(small_df)
    shuffled = small_df.copy()
    shuffled["is_fraud"] = np.random.default_rng(1).permutation(shuffled["is_fraud"].to_numpy())
    shuffled["attack"] = "x"
    _eq(build_features(small_df, v), build_features(shuffled, v))


def test_unsorted_input_is_rejected(small_df):
    with pytest.raises(ValueError):
        build_features(small_df.iloc[::-1].reset_index(drop=True), fit_vocab(small_df))


def test_first_transaction_of_a_card_has_no_history(small_df):
    X = build_features(small_df, fit_vocab(small_df))
    first = ~small_df["card_id"].duplicated()
    assert (X.loc[first, "n_prior"] == 0).all()
    assert X.loc[first, "amt_z"].isna().all()
    assert (X.loc[first, ["n_1h", "n_24h", "n_7d"]] == 0).all().all()


def test_null_card_ids_are_rejected(small_df):
    d = small_df.copy()
    d.loc[d.index[:5], "card_id"] = None
    with pytest.raises(ValueError, match="card_id"):
        build_features(d, fit_vocab(small_df))
