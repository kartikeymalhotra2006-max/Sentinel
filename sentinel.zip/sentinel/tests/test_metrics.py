import itertools
import numpy as np
import pytest

from sentinel.config import CostModel
from sentinel.drift import psi
from sentinel.metrics import (approve_all_cost, ece, optimise_thresholds, policy_cost, recall_at_fpr)


def test_recall_at_fpr_perfect_and_random():
    y = np.array([0] * 990 + [1] * 10)
    assert recall_at_fpr(y, np.r_[np.zeros(990), np.ones(10)], 0.01) == 1.0
    rng = np.random.default_rng(0)
    y = (rng.random(50_000) < 0.05).astype(int)
    assert recall_at_fpr(y, rng.random(50_000), 0.01) < 0.05


def test_policy_cost_hand_computed():
    cm = CostModel(decline_cost=10, review_cost=2, review_catch_rate=0.5)
    score = np.array([0.1, 0.2, 0.5, 0.9, 0.95, 0.3])
    y = np.array([0, 1, 1, 1, 0, 0])
    amt = np.array([10, 100, 40, 200, 30, 5.0])
    c = policy_cost(score, y, amt, t_rev=0.4, t_dec=0.9, cm=cm)
    # approve: idx0,1,5 -> missed fraud = 100.  review: idx2 (fraud 40, half missed=20), review fee 2.
    # decline: idx3 (fraud caught), idx4 (legit declined = 10)
    assert c["total"] == pytest.approx(100 + 20 + 2 + 10)
    assert c["n_decline"] == 2 and c["n_review"] == 1
    assert approve_all_cost(y, amt) == 340


def test_optimiser_matches_brute_force():
    rng = np.random.default_rng(3)
    n = 400
    y = (rng.random(n) < 0.1).astype(int)
    s = np.clip(rng.normal(0.25 + 0.5 * y, 0.2), 0, 1)
    amt = rng.uniform(5, 300, n)
    cm = CostModel()
    t_rev, t_dec = optimise_thresholds(s, y, amt, cm, k=60)
    got = policy_cost(s, y, amt, t_rev, t_dec, cm)["total"]
    cand = np.unique(np.r_[np.quantile(s, np.linspace(0.30, 0.99995, 60)), np.inf])
    best = min(policy_cost(s, y, amt, a, b, cm)["total"] for a, b in itertools.product(cand, cand) if a <= b)
    assert got == pytest.approx(best)
    assert got <= approve_all_cost(y, amt)


def test_ece_calibrated_vs_miscalibrated():
    rng = np.random.default_rng(1)
    p = rng.random(40_000)
    y = (rng.random(40_000) < p).astype(int)
    assert ece(y, p) < 0.02
    assert ece(y, np.clip(p * 0.3, 0, 1)) > 0.15


def test_psi_behaviour():
    rng = np.random.default_rng(2)
    a = rng.normal(0, 1, 20_000)
    assert psi(a, rng.normal(0, 1, 20_000)) < 0.02
    assert psi(a, rng.normal(1.5, 1, 20_000)) > 0.25
    assert psi(np.r_[a, [np.nan] * 2000], np.r_[a, [np.nan] * 8000]) > 0.05     # NaN share shift is detected


def test_thresholds_never_sit_exactly_on_a_tied_score():
    """Regression: a threshold equal to a score shared by many rows flips on 1e-16 noise between code paths."""
    rng = np.random.default_rng(5)
    n = 3000
    y = (rng.random(n) < 0.08).astype(int)
    s = np.where(rng.random(n) < 0.6, 0.0013, np.clip(rng.normal(0.2 + 0.5 * y, 0.2), 0.01, 1))   # 60% exact ties
    amt = rng.uniform(5, 300, n)
    cm = CostModel()
    t_rev, t_dec = optimise_thresholds(s, y, amt, cm)
    for t in (t_rev, t_dec):
        assert t == np.inf or not np.isin(t, s)
        assert t == np.inf or np.min(np.abs(s - t)) > 1e-10         # far above float noise (~1e-16)
    jitter = s * (1 + rng.normal(0, 1e-13, n))
    a = policy_cost(s, y, amt, t_rev, t_dec, cm); b = policy_cost(jitter, y, amt, t_rev, t_dec, cm)
    assert (a["n_decline"], a["n_review"]) == (b["n_decline"], b["n_review"])
