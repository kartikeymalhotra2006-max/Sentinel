"""Training/serving skew guard: the online featurizer must reproduce the batch features."""
import numpy as np
import pandas as pd

from sentinel.config import FEATURES
from sentinel.features import build_features, fit_vocab
from sentinel.serve.online import OnlineFeaturizer
from sentinel.serve.state import InMemoryStore, RedisStore
from sentinel.serve.warm import row_to_txn


def _stream(df, store, vocab):
    fz = OnlineFeaturizer(store, vocab)
    rows = []
    for r in df.to_dict("records"):
        t = row_to_txn(r)
        f = fz.features(t)
        fz.commit(t)
        rows.append([f[k] for k in FEATURES])
    return np.array(rows, float)


def test_online_equals_batch(small_df):
    v = fit_vocab(small_df)
    np.testing.assert_allclose(build_features(small_df, v).to_numpy(float), _stream(small_df, InMemoryStore(), v),
                               rtol=1e-7, atol=1e-6, equal_nan=True)


def test_parity_with_missing_device_ids(small_df):
    d = small_df.copy()
    d.loc[d.sample(frac=0.25, random_state=0).index, "device_id"] = None
    v = fit_vocab(d)
    B = build_features(d, v)
    assert B["pair_new"].isna().sum() == d["device_id"].isna().sum()
    np.testing.assert_allclose(B.to_numpy(float), _stream(d, InMemoryStore(), v), rtol=1e-7, atol=1e-6, equal_nan=True)


def test_redis_store_matches_memory_store(small_df):
    import fakeredis
    d = small_df.iloc[:1500].copy()
    v = fit_vocab(d)
    a = _stream(d, InMemoryStore(), v)
    b = _stream(d, RedisStore(fakeredis.FakeRedis()), v)
    np.testing.assert_allclose(a, b, equal_nan=True)


def test_parity_on_exact_window_boundaries_and_ties():
    """Random data rarely lands exactly on a window edge; craft it. Windows are inclusive of t - w."""
    rows = []
    for t in [0, 3600, 3600, 7200, 7200, 7201, 86_400, 86_400 + 3600, 7 * 86_400, 7 * 86_400 + 3600, 8 * 86_400]:
        rows.append(("A", t, 10.0 + t % 7, "d1"))
    for t in [100, 3700, 3700, 90_100]:
        rows.append(("B", t, 50.0, "d1"))          # second card on the same device => device-level windows
    rows.sort(key=lambda r: r[1])
    df = pd.DataFrame(rows, columns=["card_id", "ts", "amount", "device_id"])
    df["product"], df["email_domain"], df["device_type"] = "W", "gmail.com", "mobile"
    v = {"product": ["W"], "email_domain": ["gmail.com"], "device_type": ["mobile"]}
    np.testing.assert_allclose(build_features(df, v).to_numpy(float), _stream(df, InMemoryStore(), v), equal_nan=True)
    X = build_features(df, v)
    a = X[df.card_id.eq("A")].reset_index(drop=True)
    assert a.loc[1, "n_1h"] == 1          # txn at 3600 sees txn at 0 (exactly one hour earlier => inside window)
    assert a.loc[2, "n_1h"] == 2          # same-second tie: earlier arrival counts, itself does not
