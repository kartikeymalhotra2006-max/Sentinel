import numpy as np
import pandas as pd
import pytest
from fastapi.testclient import TestClient

from sentinel.serve.app import create_app
from sentinel.serve.state import InMemoryStore


def txn(i, **kw):
    d = {"txn_id": f"t{i}", "ts": 1_000_000 + i, "card_id": "cardA", "amount": 25.0, "device_id": "dev1",
         "product": "W", "email_domain": "gmail.com", "device_type": "mobile"}
    d.update(kw)
    return d


@pytest.fixture()
def client(trained):
    out, _ = trained
    with TestClient(create_app(str(out / "bundle.joblib"), InMemoryStore())) as c:
        yield c


def test_health_and_model(client):
    assert client.get("/health").json()["status"] == "ok"
    m = client.get("/model").json()
    assert m["thresholds"]["review"] < m["thresholds"]["decline"]


def test_score_schema(client):
    r = client.post("/score", json=txn(1))
    assert r.status_code == 200
    b = r.json()
    assert 0 <= b["risk"] <= 1 and b["decision"] in {"approve", "review", "decline"}
    assert b["latency_ms"] < 250 and b["model_version"]


@pytest.mark.parametrize("bad", [{"amount": 0}, {"amount": -5}, {"card_id": ""}, {"ts": -1}])
def test_validation_rejects_bad_input(client, bad):
    assert client.post("/score", json=txn(1, **bad)).status_code == 422


def test_idempotent_retry_does_not_double_count(client):
    a = client.post("/score", json=txn(1)).json()
    b = client.post("/score", json=txn(1)).json()
    assert b["replayed"] is True and a["risk"] == b["risk"]
    c = client.post("/score", json=txn(2, ts=1_000_100)).json()          # history has exactly 1 prior txn
    assert c["replayed"] is False


def test_dry_run_does_not_mutate_state(client):
    r1 = client.post("/score?commit=false", json=txn(10, txn_id=None)).json()["risk"]
    r2 = client.post("/score?commit=false", json=txn(10, txn_id=None)).json()["risk"]
    assert r1 == r2


def test_burst_from_new_device_raises_risk(client):
    for i in range(20):                                                   # normal history
        client.post("/score", json=txn(100 + i, ts=1_000_000 + i * 86_400 // 2, device_id="home"))
    base = client.post("/score?commit=false", json=txn(200, ts=1_000_000 + 20 * 43_200, device_id="home", txn_id=None)).json()["risk"]
    risks = []
    t0 = 1_000_000 + 21 * 43_200
    for i in range(8):
        risks.append(client.post("/score", json=txn(300 + i, ts=t0 + i * 60, device_id="fraud_dev", amount=900.0)).json()["risk"])
    assert max(risks) > base and risks[-1] > base


def test_out_of_order_is_flagged(client):
    client.post("/score", json=txn(1, ts=2_000_000))
    assert client.post("/score", json=txn(2, ts=1_999_000)).json()["out_of_order"] is True


def test_drift_endpoint(client):
    assert client.get("/drift").json()["status"] == "insufficient_data"
    for i in range(220):
        client.post("/score", json=txn(1000 + i, card_id=f"c{i % 40}", ts=3_000_000 + i * 30, amount=20 + (i % 9)))
    d = client.get("/drift").json()
    assert d["status"] == "ok" and "score_psi" in d


def test_stacked_model_serves(trained_stacked):
    with TestClient(create_app(str(trained_stacked / "bundle.joblib"), InMemoryStore())) as c:
        r = c.post("/score", json=txn(1))
        assert r.status_code == 200 and 0 <= r.json()["risk"] <= 1


@pytest.mark.parametrize("which", ["lgb", "stacked"])
def test_live_api_matches_offline_batch_scores(trained, trained_stacked, which):
    """End-to-end skew check: warm the online state with history, then every live score must equal the
    score the offline batch pipeline assigned to the same transaction."""
    from sentinel.serve.warm import row_to_txn
    out = trained[0] if which == "lgb" else trained_stacked
    rp = pd.read_csv(out / "replay.csv.gz")
    warm, test = rp[rp.phase == "warm"], rp[rp.phase == "test"].head(250)
    with TestClient(create_app(str(out / "bundle.joblib"), InMemoryStore())) as c:
        fz = c.app.state.featurizer
        for r in warm.to_dict("records"):
            fz.commit(row_to_txn(r))
        live, dec = [], []
        for r in test.to_dict("records"):
            j = c.post("/score", json=row_to_txn(r)).json()
            live.append(j["risk"]); dec.append(j["decision"])
    np.testing.assert_allclose(live, test["risk"].to_numpy(), atol=2e-6)
    # decisions (not just scores) must agree: thresholds sit in gaps, so float noise cannot flip a band
    th = __import__("joblib").load(out / "bundle.joblib")["thresholds"]
    off = np.where(test["risk"] >= th["decline"], "decline", np.where(test["risk"] >= th["review"], "review", "approve"))
    assert (np.array(dec) == off).all()


def test_ingest_warms_state_without_scoring_or_drift_stats(client):
    hist = [txn(i, txn_id=None, ts=1_000_000 + i * 3600, device_id="dev1") for i in range(30)]
    assert client.post("/ingest", json={"txns": hist}).json() == {"ingested": 30}
    assert client.get("/model").json()["decisions_served"] == {"approve": 0, "review": 0, "decline": 0}
    assert len(client.app.state.recent) == 0
    f = client.app.state.featurizer.features(txn(99, txn_id=None, ts=1_000_000 + 31 * 3600))
    assert f["n_prior"] == 30.0


def test_reason_codes_are_human_readable(client):
    for i in range(6):
        r = client.post("/score", json=txn(500 + i, ts=5_000_000 + i * 30, card_id="victim", device_id="fraudbox", amount=800.0)).json()
    assert r["reasons"], "a rapid burst on a brand-new device should produce reasons"
    for x in r["reasons"]:
        assert x["detail"] and "unavailable" not in x["detail"]
