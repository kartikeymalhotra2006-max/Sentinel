from argparse import Namespace
import pytest

from sentinel.data.synth import generate
from sentinel.pipeline import run


def _args(out, final=None):
    return Namespace(data="synthetic", ieee_dir=None, out=str(out), n_txn=30_000, seed=3, tune=0, boot=5,
                     decline_cost=15.0, review_cost=3.0, catch_rate=0.85, force_final=final)


@pytest.fixture(scope="session")
def small_df():
    return generate(n_txn=6000, n_cards=300, seed=3)


@pytest.fixture(scope="session")
def trained(tmp_path_factory):
    out = tmp_path_factory.mktemp("art_lgb")
    R = run(_args(out, "lightgbm"))
    return out, R


@pytest.fixture(scope="session")
def trained_stacked(tmp_path_factory):
    out = tmp_path_factory.mktemp("art_stk")
    run(_args(out, "stacked"))
    return out
