# Model card — Sentinel fraud scorer

**Intended use.** Rank card transactions by fraud risk in real time and route them to approve / manual review / decline.
Not for credit decisions or any use affecting people outside payment-fraud screening.

**Data.** Trained and evaluated on synthetic transactions (150k rows, 3.0% fraud, 8% of fraud labels dropped to mimic label noise)
or, when run with `--data ieee`, on Kaggle IEEE-CIS. The bundle records which in `metadata.data`. Synthetic results do not transfer.

**Model.** LightGBM on 20 behavioural features (card velocity, amount-vs-history, device-graph, time, three categoricals),
Platt-calibrated. Thresholds minimise expected cost on a validation window under the configured cost model.

**Evaluation (synthetic, final 15% of time).** PR-AUC 0.669 (95% CI 0.584–0.742), recall at 1% FPR 0.667, ECE 0.0058,
69.3% lower expected cost than approving everything.

**Known weaknesses.** Misses a late-emerging low-and-slow attack (10% flagged). Depends heavily on device features, which are
weak or missing on IEEE-CIS. Cold-start cards (no history) are scored with missing features.

**Fairness.** Segment false-positive rates differ (device type, amount band) and are reported in `results.json`. No protected
attributes are used or available; proxies should be reviewed before real deployment.

**Monitoring.** Weekly PR-AUC/recall (needs delayed labels) plus score/feature PSI. PSI alone is insufficient: it missed the drift above.
Retrain when the recall alert fires; the retraining experiment is in `results.json`.

**Human oversight.** The review band exists so uncertain cases go to analysts; every non-approve decision carries reason codes.
