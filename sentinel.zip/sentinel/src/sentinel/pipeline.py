"""End-to-end training + evaluation pipeline.

    python -m sentinel.pipeline --data synthetic --out artifacts
    python -m sentinel.pipeline --data ieee --ieee-dir /path/to/ieee-fraud-detection --out artifacts --tune 30

Writes to --out: bundle.joblib (deployable model), results.json, results.md, plots/*.png,
and (synthetic only) replay.csv.gz for the demo.
"""
import argparse
import datetime
import hashlib
import json
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, brier_score_loss

from . import __version__, report
from .config import FEATURE_FAMILIES, FEATURES, CostModel
from .drift import feature_psi, weekly_report
from .explain import contributions
from .features import build_features, fit_vocab
from .metrics import (approve_all_cost, cluster_bootstrap_ap, ece, optimise_thresholds, policy_cost,
                      ranking_metrics)
from .models import (anomaly_score, apply_platt, fit_anomaly, fit_lgbm, fit_lgbm_fixed, fit_logistic,
                     fit_platt, lr_margin, margin, time_splits, tune)


def load_dataset(data="synthetic", ieee_dir=None, n_txn=150_000, seed=7) -> pd.DataFrame:
    if data == "ieee":
        from .data.ieee import load_ieee
        return load_ieee(ieee_dir)
    from .data.synth import generate
    return generate(n_txn=n_txn, n_cards=max(300, n_txn // 21), seed=seed)


MIN_FRAUD_PER_SPLIT = 30


def _f(x):
    return float(x) if x == x else None


def run(args):
    t_start = time.time()
    out = Path(args.out); (out / "plots").mkdir(parents=True, exist_ok=True)
    cm = CostModel(args.decline_cost, args.review_cost, args.catch_rate)
    log = lambda m: print(f"[{time.time() - t_start:6.1f}s] {m}", flush=True)

    df = load_dataset(args.data, args.ieee_dir, args.n_txn, args.seed)
    n = len(df); sp = time_splits(n)
    y = df["is_fraud"].to_numpy(); amt = df["amount"].to_numpy(); ts = df["ts"].to_numpy()
    R = {"meta": {"data": args.data, "n_rows": int(n), "fraud_rate": float(y.mean()), "cost_model": cm.as_dict(),
                  "splits": {k: {"rows": int(s.stop - s.start), "fraud": int(y[s].sum())} for k, s in sp.items()},
                  "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
                  "sentinel_version": __version__}}
    log(f"data: {n:,} rows, fraud rate {y.mean():.2%}")
    thin = {k: int(y[v].sum()) for k, v in sp.items() if y[v].sum() < MIN_FRAUD_PER_SPLIT}
    if thin:
        raise ValueError(f"Too few fraud rows in splits {thin} (need >= {MIN_FRAUD_PER_SPLIT} each for stable thresholds "
                         f"and metrics). Use more data (--n-txn) or a different --seed.")

    vocab = fit_vocab(df.iloc[sp["train"]])
    X = build_features(df, vocab)
    log("features built")
    Xtr, ytr, Xes, yes = X.iloc[sp["train"]], y[sp["train"]], X.iloc[sp["es"]], y[sp["es"]]
    ratio = (1 - ytr.mean()) / ytr.mean()

    # ---- 1. imbalance study (honest comparison of weighting strategies on validation) ----------
    study = {}
    for name, spw in {"none": 1.0, "sqrt": float(np.sqrt(ratio)), "full": float(ratio)}.items():
        b = fit_lgbm(Xtr, ytr, Xes, yes, spw=spw)
        study[name] = {"scale_pos_weight": spw, "val_pr_auc": float(average_precision_score(y[sp["val"]], margin(b, X.iloc[sp["val"]])))}
    best_w = max(study, key=lambda k: study[k]["val_pr_auc"])
    R["imbalance_study"] = {"results": study, "chosen": best_w,
                            "note": "SMOTE intentionally not used: time-dependent behavioural features and categorical codes make synthetic oversampling unrealistic; weighting is the leakage-safe alternative."}
    params, spw = {}, study[best_w]["scale_pos_weight"]
    if args.tune > 0:
        params, spw, cv = tune(Xtr, ytr, args.tune)
        R["tuning"] = {"trials": args.tune, "cv_pr_auc": cv, "best_params": params, "scale_pos_weight": spw}
        log(f"tuned (time-series CV PR-AUC {cv:.3f})")
    log(f"imbalance: {best_w} -> {study[best_w]['val_pr_auc']:.3f} val PR-AUC")

    # ---- 2. models ---------------------------------------------------------------------------
    M = {}
    lr = fit_logistic(Xtr, ytr)
    M["logistic"] = {"raw": lr_margin(lr, X), "model": lr}
    lgb1 = fit_lgbm(Xtr, ytr, Xes, yes, params, spw)
    M["lightgbm"] = {"raw": margin(lgb1, X), "booster": lgb1, "X": X}
    iso = fit_anomaly(Xtr)
    Xa = X.copy(); Xa["anomaly_score"] = anomaly_score(iso, X)
    lgb2 = fit_lgbm(Xa.iloc[sp["train"]], ytr, Xa.iloc[sp["es"]], yes, params, spw)
    M["stacked"] = {"raw": margin(lgb2, Xa), "booster": lgb2, "X": Xa}
    log(f"trained: lightgbm {lgb1.best_iteration} rounds, stacked {lgb2.best_iteration} rounds")

    base_cost = {k: approve_all_cost(y[sp[k]], amt[sp[k]]) for k in ("val", "test")}
    R["models"] = {}
    for name, m in M.items():
        ab = fit_platt(m["raw"][sp["calib"]], y[sp["calib"]])
        m["ab"], m["prob"] = ab, apply_platt(m["raw"], ab)
        pv, pt = m["prob"][sp["val"]], m["prob"][sp["test"]]
        t_rev, t_dec = optimise_thresholds(pv, y[sp["val"]], amt[sp["val"]], cm)
        m["thr"] = (t_rev, t_dec)
        lo, hi = cluster_bootstrap_ap(y[sp["test"]], pt, df["card_id"].to_numpy()[sp["test"]], n_boot=args.boot)
        c_test = policy_cost(pt, y[sp["test"]], amt[sp["test"]], t_rev, t_dec, cm)
        R["models"][name] = {
            "val": ranking_metrics(y[sp["val"]], pv), "test": ranking_metrics(y[sp["test"]], pt),
            "test_pr_auc_ci95": [lo, hi], "test_ece": ece(y[sp["test"]], pt), "test_brier": float(brier_score_loss(y[sp["test"]], pt)),
            "thresholds": {"review": t_rev, "decline": t_dec}, "test_cost": c_test,
            "test_cost_saving_vs_approve_all": 1 - c_test["total"] / base_cost["test"]}
    R["approve_all_cost"] = base_cost

    final = getattr(args, "force_final", None) or max(("lightgbm", "stacked"), key=lambda k: R["models"][k]["val"]["pr_auc"])
    R["final_model"] = final
    F = M[final]; fb = F["booster"]; FX = F["X"]; t_rev, t_dec = F["thr"]
    pt = F["prob"][sp["test"]]; yt = y[sp["test"]]
    log(f"final model: {final}")

    # ---- 3. error analysis -------------------------------------------------------------------
    te = df.iloc[sp["test"]].copy(); te["p"] = pt; te["flag"] = pt >= t_rev; te["decline"] = pt >= t_dec
    att = {}
    for a in sorted(te.loc[te.is_fraud == 1, "attack"].unique()):
        mk = (te.attack == a) | (te.attack == "legit")
        sub = te[te.attack == a]
        att[a] = {"fraud_rows": int(len(sub)), "recall_flagged": float(sub.flag.mean()), "recall_declined": float(sub.decline.mean()),
                  "pr_auc_vs_legit": float(average_precision_score(te.is_fraud[mk], te.p[mk])) if len(sub) >= 5 else None}
    R["by_attack_type_test"] = att
    te["amount_band"] = pd.cut(te.amount, [0, 10, 50, 200, 1e9], labels=["<$10", "$10-50", "$50-200", "$200+"])
    seg = {}
    for col in ("amount_band", "device_type", "product", "email_domain"):
        rows = []
        for k, g in te.groupby(col, observed=True):
            lg, fr = g[g.is_fraud == 0], g[g.is_fraud == 1]
            if len(g) < 200:
                continue
            rows.append({"segment": str(k), "n": int(len(g)), "fraud_rate": float(g.is_fraud.mean()),
                         "false_positive_rate": _f(lg.flag.mean()), "fraud_recall": _f(fr.flag.mean()) if len(fr) >= 5 else None})
        seg[col] = rows
    R["segments_test"] = seg

    # ---- 4. ablation (drop one feature family; retrain with identical settings) -----------------
    abl = [("all features", R["models"]["lightgbm"]["test"]["pr_auc"])]
    for fam, cols in FEATURE_FAMILIES.items():
        keep = [c for c in FEATURES if c not in cols]
        b = fit_lgbm(Xtr[keep], ytr, Xes[keep], yes, params, spw)
        abl.append((f"- {fam}", float(average_precision_score(yt, margin(b, X.iloc[sp["test"]][keep])))))
    R["ablation_test_pr_auc"] = dict(abl)
    log("ablation done")

    # ---- 5. explainability --------------------------------------------------------------------
    rng = np.random.default_rng(0)
    te_idx = np.arange(sp["test"].start, sp["test"].stop)
    samp = rng.choice(te_idx, min(4000, len(te_idx)), replace=False)
    contrib = contributions(fb, FX.iloc[samp].to_numpy())
    imp = pd.Series(np.abs(contrib[:, :-1]).mean(0), index=FX.columns).sort_values(ascending=False)
    R["shap_mean_abs"] = {k: float(v) for k, v in imp.head(12).items()}

    # ---- 6. drift & retraining ----------------------------------------------------------------
    R["feature_psi_train_vs_test"] = {k: float(v) for k, v in feature_psi(Xtr, X.iloc[sp["test"]]).head(8).items()}
    v0 = sp["val"].start
    ref_recall = float((F["prob"][sp["val"]][y[sp["val"]] == 1] >= t_rev).mean())
    weekly = weekly_report(ts[v0:], y[v0:], F["prob"][v0:], F["prob"][sp["calib"]], t_rev, ref_recall=ref_recall)
    R["reference_recall_flagged_val"] = ref_recall
    R["weekly"] = json.loads(weekly.to_json(orient="records"))
    blocks = np.array_split(np.arange(sp["test"].start, sp["test"].stop), 3)
    rt = []
    mats = FX
    for i, bl in enumerate(blocks):
        s0 = bl[0]
        rb = fit_lgbm_fixed(mats.iloc[:s0], y[:s0], params, spw, max(fb.best_iteration, 50))
        rt.append({"block": i + 1, "rows": int(len(bl)), "fraud": int(y[bl].sum()),
                   "frozen_pr_auc": float(average_precision_score(y[bl], F["raw"][bl])),
                   "retrained_pr_auc": float(average_precision_score(y[bl], margin(rb, mats.iloc[bl])))})
    R["retrain_experiment"] = rt
    log("drift & retrain done")

    # ---- 7. figures ----------------------------------------------------------------------------
    P = out / "plots"
    report.pr_curves(yt, {k: M[k]["prob"][sp["test"]] for k in M}, P / "pr_curve.png")
    report.cost_curve(yt, pt, amt[sp["test"]], cm, t_rev, t_dec, P / "cost_curve.png")
    report.reliability(yt, pt, P / "calibration.png")
    report.shap_bar(contrib, list(FX.columns), P / "shap_global.png")
    report.ablation_bar(abl, P / "ablation.png")
    report.drift_plot(weekly, P / "drift_weekly.png")
    report.retrain_plot(rt, P / "retrain.png")

    # ---- 8. deployable bundle -------------------------------------------------------------------
    model_str = fb.model_to_string(num_iteration=fb.best_iteration)
    ref_rows = np.arange(sp["calib"].start, sp["calib"].stop)        # recent, pre-deployment reference window
    ref_idx = rng.choice(ref_rows, min(5000, len(ref_rows)), replace=False)
    version = datetime.datetime.now(datetime.timezone.utc).strftime("%Y.%m.%d") + "-" + hashlib.sha1(model_str.encode()).hexdigest()[:7]
    bundle = {"version": version, "model_str": model_str, "feature_names": list(FX.columns), "vocab": vocab,
              "use_anomaly": final == "stacked", "anomaly": iso if final == "stacked" else None,
              "platt": F["ab"], "thresholds": {"review": t_rev, "decline": t_dec}, "cost_model": cm.as_dict(),
              "reference": {"features": FX.iloc[ref_idx][FEATURES].astype("float64").reset_index(drop=True),
                            "scores": np.asarray(F["prob"][sp["calib"]], dtype="float64")},
              "metadata": {"data": args.data, "metrics_test": R["models"][final]["test"], "trained_rows": int(sp["train"].stop)}}
    joblib.dump(bundle, out / "bundle.joblib", compress=3)
    R["meta"]["bundle_version"] = version
    if args.data == "synthetic":      # full stream + offline risk: lets the API be checked against batch scoring
        rp = df.copy(); rp["phase"] = np.where(np.arange(n) < sp["test"].start, "warm", "test")
        rp["risk"] = F["prob"]
        rp.to_csv(out / "replay.csv.gz", index=False)

    R["meta"]["runtime_seconds"] = round(time.time() - t_start, 1)
    (out / "results.json").write_text(json.dumps(R, indent=2, default=float))
    (out / "results.md").write_text(to_markdown(R))
    log(f"done -> {out}")
    return R


def to_markdown(R) -> str:
    m, fm = R["models"], R["final_model"]
    L = [f"# Results ({R['meta']['data']} data, {R['meta']['n_rows']:,} rows, fraud rate {R['meta']['fraud_rate']:.2%})", "",
         "All numbers are on the chronologically last 15% of the data (never seen in training, calibration or threshold selection).", "",
         "| Model | PR-AUC (95% CI) | ROC-AUC | Recall @ 1% FPR | ECE | Expected cost | Saving vs approve-all |", "|---|---|---|---|---|---|---|"]
    for k, v in m.items():
        t = v["test"]; ci = v["test_pr_auc_ci95"]
        L.append(f"| {k}{' **(final)**' if k == fm else ''} | {t['pr_auc']:.3f} ({ci[0]:.3f}-{ci[1]:.3f}) | {t['roc_auc']:.3f} | {t['recall_at_1pct_fpr']:.3f} | "
                 f"{v['test_ece']:.4f} | ${v['test_cost']['total']:,.0f} | {v['test_cost_saving_vs_approve_all']:.1%} |")
    L += ["", f"Approve-everything baseline cost on test: ${R['approve_all_cost']['test']:,.0f}.", "",
          "## By attack type (final model, test)", "", "| Attack | Fraud rows | Flagged | Declined |", "|---|---|---|---|"]
    for a, v in R["by_attack_type_test"].items():
        L.append(f"| {a} | {v['fraud_rows']} | {v['recall_flagged']:.1%} | {v['recall_declined']:.1%} |")
    L += ["", "## Ablation (test PR-AUC)", ""] + [f"- {k}: {v:.3f}" for k, v in R["ablation_test_pr_auc"].items()]
    L += ["", "## Drift: frozen vs retrained", "", "| Block | Fraud | Frozen PR-AUC | Retrained PR-AUC |", "|---|---|---|---|"]
    for r in R["retrain_experiment"]:
        L.append(f"| {r['block']} | {r['fraud']} | {r['frozen_pr_auc']:.3f} | {r['retrained_pr_auc']:.3f} |")
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", choices=["synthetic", "ieee"], default="synthetic")
    ap.add_argument("--ieee-dir"); ap.add_argument("--out", default="artifacts")
    ap.add_argument("--n-txn", type=int, default=150_000); ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--tune", type=int, default=0, help="Optuna trials (0 = skip)")
    ap.add_argument("--boot", type=int, default=200)
    ap.add_argument("--force-final", choices=["lightgbm", "stacked"], help="override model selection (used by tests)")
    ap.add_argument("--decline-cost", type=float, default=15.0); ap.add_argument("--review-cost", type=float, default=3.0)
    ap.add_argument("--catch-rate", type=float, default=0.85)
    run(ap.parse_args())


if __name__ == "__main__":
    main()
