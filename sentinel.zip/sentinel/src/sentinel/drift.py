"""Population Stability Index (PSI) drift monitoring and windowed performance tracking."""
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

EPS = 1e-4


def psi(expected, actual, bins=10) -> float:
    """PSI of `actual` vs `expected`. NaN is its own bucket. Rule of thumb: <0.1 stable,
    0.1-0.25 moderate shift, >0.25 major shift."""
    e, a = np.asarray(expected, float), np.asarray(actual, float)
    en, an = np.isnan(e), np.isnan(a)
    ev, av = e[~en], a[~an]
    if len(ev) == 0 or len(av) == 0:
        return 0.0
    uniq = np.unique(ev)
    if len(uniq) <= 20:
        edges = np.r_[uniq - 0.5, uniq[-1] + 0.5]
    else:
        edges = np.unique(np.quantile(ev, np.linspace(0, 1, bins + 1)))
        edges[0], edges[-1] = -np.inf, np.inf
    pe = np.r_[np.histogram(ev, edges)[0], en.sum()] / len(e) + EPS
    pa = np.r_[np.histogram(av, edges)[0], an.sum()] / len(a) + EPS
    return float(np.sum((pa - pe) * np.log(pa / pe)))


def feature_psi(ref: pd.DataFrame, cur: pd.DataFrame) -> pd.Series:
    return pd.Series({c: psi(ref[c], cur[c]) for c in ref.columns}).sort_values(ascending=False)


def weekly_report(ts, y, score, ref_score, t_review, ref_recall=None, week=7 * 86400, min_fraud=8,
                  recall_drop=0.15) -> pd.DataFrame:
    """Per-week monitoring table. Two independent alerts:
    * score_psi > 0.2         - input/score distribution moved (works without labels)
    * recall drop > 15 points - fraud caught fell vs reference (needs delayed labels).
    A new attack that *evades* the model barely moves the score distribution, so only the second
    alert catches it; that is why both are tracked."""
    ts, y, score = map(np.asarray, (ts, y, score))
    w = ts // week
    rows = []
    for k in np.unique(w):
        m = w == k
        nf = int(y[m].sum())
        flagged = score[m] >= t_review
        rows.append({"week": int(k), "n": int(m.sum()), "n_fraud": nf,
                     "pr_auc": float(average_precision_score(y[m], score[m])) if nf >= min_fraud else np.nan,
                     "fraud_recall_flagged": float(flagged[y[m] == 1].mean()) if nf else np.nan,
                     "false_positive_rate": float(flagged[y[m] == 0].mean()),
                     "score_psi": psi(ref_score, score[m])})
    r = pd.DataFrame(rows)
    r["psi_alert"] = r["score_psi"] > 0.2
    r["recall_alert"] = (r["fraud_recall_flagged"] < ref_recall - recall_drop) if ref_recall is not None else False
    r["retrain_alert"] = r["psi_alert"] | r["recall_alert"]
    return r
