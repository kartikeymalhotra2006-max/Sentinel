"""Publication-style figures. One consistent visual language across all plots."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import precision_recall_curve

INK, ACC, MUTE, PAPER, GRID = "#14130f", "#d4491f", "#8d897c", "#f6f3ec", "#d9d4c7"
PAL = {"logistic": MUTE, "lightgbm": INK, "stacked": "#3b6e8f"}


def _style():
    plt.rcParams.update({
        "figure.facecolor": PAPER, "axes.facecolor": PAPER, "savefig.facecolor": PAPER,
        "axes.edgecolor": INK, "axes.labelcolor": INK, "text.color": INK, "xtick.color": INK,
        "ytick.color": INK, "axes.spines.top": False, "axes.spines.right": False,
        "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True,
        "font.family": "DejaVu Sans", "font.size": 10, "axes.titlesize": 12, "axes.titleweight": "bold",
        "axes.titlelocation": "left", "legend.frameon": False,
    })


def _save(fig, path):
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def pr_curves(y, scores: dict, path):
    _style(); fig, ax = plt.subplots(figsize=(6.2, 4.4))
    for name, s in scores.items():
        p, r, _ = precision_recall_curve(y, s)
        ax.plot(r, p, color=PAL.get(name, ACC), lw=2.2 if name == "lightgbm" else 1.6, label=name)
    ax.axhline(np.mean(y), color=ACC, ls=":", lw=1); ax.text(0.01, np.mean(y) + .02, "no-skill (fraud rate)", color=ACC, fontsize=8)
    ax.set(xlabel="Recall", ylabel="Precision", title="Precision-recall on held-out future window", xlim=(0, 1), ylim=(0, 1.02))
    ax.legend(loc="upper right"); _save(fig, path)


def cost_curve(y, score, amount, cm, t_rev, t_dec, path):
    from .metrics import policy_cost, approve_all_cost
    _style(); fig, ax = plt.subplots(figsize=(6.2, 4.4))
    ts = np.unique(np.quantile(score, np.linspace(0.5, 0.9995, 150)))
    costs = [policy_cost(score, y, amount, min(t_rev, t), t, cm)["total"] for t in ts]
    ax.plot(ts, costs, color=INK, lw=2, label="expected cost (review band held fixed)")
    ax.axhline(approve_all_cost(y, amount), color=MUTE, ls="--", label="approve everything")
    ax.axvline(t_dec, color=ACC, lw=1.5, label="chosen decline threshold")
    ax.set(xlabel="Decline threshold (calibrated risk)", ylabel="Total cost ($)", title="Business cost vs decision threshold")
    ax.legend(); _save(fig, path)


def reliability(y, p, path, bins=10):
    _style(); fig, ax = plt.subplots(figsize=(4.6, 4.4))
    edges = np.unique(np.quantile(p, np.linspace(0, 1, bins + 1)))
    idx = np.clip(np.searchsorted(edges, p, side="right") - 1, 0, len(edges) - 2)
    xs = [p[idx == b].mean() for b in range(len(edges) - 1) if (idx == b).any()]
    ys = [y[idx == b].mean() for b in range(len(edges) - 1) if (idx == b).any()]
    ax.plot([0, 1], [0, 1], color=MUTE, ls="--"); ax.plot(xs, ys, "o-", color=ACC, lw=2)
    ax.set(xlabel="Predicted risk", ylabel="Observed fraud rate", title="Calibration", xlim=(0, 1), ylim=(0, 1)); _save(fig, path)


def shap_bar(contrib, names, path, top=14):
    _style(); m = np.abs(contrib[:, :-1]).mean(0); o = np.argsort(m)[-top:]
    fig, ax = plt.subplots(figsize=(6.2, 4.6))
    ax.barh([names[i] for i in o], m[o], color=ACC); ax.grid(axis="y", visible=False)
    ax.set(xlabel="mean |SHAP| (log-odds)", title="Global feature importance (TreeSHAP)"); _save(fig, path)


def ablation_bar(rows, path):
    _style(); fig, ax = plt.subplots(figsize=(6.2, 4.0))
    names = [r[0] for r in rows]; vals = [r[1] for r in rows]
    cols = [INK if n == "all features" else ACC for n in names]
    ax.barh(names[::-1], vals[::-1], color=cols[::-1]); ax.grid(axis="y", visible=False)
    ax.set(xlabel="Test PR-AUC", title="Ablation: drop one feature family"); ax.set_xlim(0, max(vals) * 1.12)
    for i, v in enumerate(vals[::-1]): ax.text(v + 0.005, i, f"{v:.3f}", va="center", fontsize=9)
    _save(fig, path)


def drift_plot(weekly, path):
    _style()
    fig, (ax, ax2) = plt.subplots(2, 1, figsize=(7, 5.2), sharex=True, gridspec_kw={"height_ratios": [3, 1.3]})
    ax.plot(weekly["week"], weekly["pr_auc"], "o-", color=INK, lw=2, label="PR-AUC (frozen model)")
    ax.plot(weekly["week"], weekly["fraud_recall_flagged"], "s--", color="#3b6e8f", lw=1.6, label="fraud recall (flagged)")
    bad = weekly[weekly["recall_alert"]]
    ax.scatter(bad["week"], bad["fraud_recall_flagged"], s=160, facecolors="none", edgecolors=ACC, lw=2, label="recall alert fired", zorder=5)
    ax.set(ylabel="PR-AUC / recall", title="Frozen model under concept drift", ylim=(0, 1.05)); ax.legend(loc="lower left", fontsize=8)
    ax2.bar(weekly["week"], weekly["score_psi"], color=ACC, alpha=.45, width=.6)
    ax2.axhline(0.2, color=ACC, ls="--", lw=1); ax2.text(weekly["week"].min() - .4, 0.205, "PSI alert level 0.2", color=ACC, fontsize=8, va="bottom")
    ax2.set(xlabel="Week index", ylabel="score PSI", ylim=(0, 0.3))
    _save(fig, path)


def retrain_plot(rows, path):
    _style(); fig, ax = plt.subplots(figsize=(6.2, 4.0)); x = np.arange(len(rows))
    ax.bar(x - .2, [r["frozen_pr_auc"] for r in rows], .4, color=MUTE, label="frozen model")
    ax.bar(x + .2, [r["retrained_pr_auc"] for r in rows], .4, color=ACC, label="retrained on all data before block")
    ax.set_xticks(x); ax.set_xticklabels([f"block {i+1}" for i in x]); ax.set(ylabel="PR-AUC", title="Retraining recovers performance", ylim=(0, 1)); ax.legend(loc="lower right")
    ax.grid(axis="x", visible=False); _save(fig, path)
