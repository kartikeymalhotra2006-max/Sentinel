"""Model training: logistic baseline, LightGBM, anomaly stacking, Platt calibration, tuning."""
import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import IsolationForest
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler

from .config import ANOMALY_FEATURES, CATEGORICALS, NUMERIC_FEATURES, SPLITS

LGB_BASE = dict(objective="binary", learning_rate=0.05, num_leaves=63, min_child_samples=40,
                feature_fraction=0.8, bagging_fraction=0.8, bagging_freq=1, lambda_l2=5.0,
                metric="average_precision", verbose=-1, num_threads=0, seed=42,
                deterministic=True, force_row_wise=True)


def time_splits(n: int, fractions=SPLITS) -> dict:
    bounds = np.r_[0, np.round(np.cumsum(list(fractions.values())) * n).astype(int)]
    bounds[-1] = n
    return {k: slice(bounds[i], bounds[i + 1]) for i, k in enumerate(fractions)}


# --------------------------------------------------------------------------- baseline ------
def _slog(x):
    return np.sign(x) * np.log1p(np.abs(x))


def fit_logistic(X: pd.DataFrame, y) -> Pipeline:
    pre = ColumnTransformer([
        ("num", Pipeline([("slog", FunctionTransformer(_slog)),
                          ("imp", SimpleImputer(strategy="median", add_indicator=True)),
                          ("sc", StandardScaler())]), NUMERIC_FEATURES),
        ("cat", OneHotEncoder(handle_unknown="ignore", min_frequency=20), CATEGORICALS),
    ])
    pipe = Pipeline([("pre", pre), ("lr", LogisticRegression(C=1.0, max_iter=500, class_weight="balanced"))])
    return pipe.fit(X, y)


def lr_margin(pipe, X):
    return pipe.decision_function(X)


# --------------------------------------------------------------------------- anomaly -------
def fit_anomaly(X: pd.DataFrame, seed=42) -> Pipeline:
    pipe = Pipeline([("imp", SimpleImputer(strategy="median")),
                     ("iso", IsolationForest(n_estimators=100, max_samples=2048, random_state=seed, n_jobs=1))])
    return pipe.fit(X[ANOMALY_FEATURES].to_numpy())


def anomaly_score(pipe, X: pd.DataFrame) -> np.ndarray:
    return -pipe.decision_function(X[ANOMALY_FEATURES].to_numpy())


# --------------------------------------------------------------------------- lightgbm ------
def fit_lgbm(Xtr, ytr, Xes, yes, params=None, spw=1.0, rounds=1500, es=50):
    p = {**LGB_BASE, **(params or {}), "scale_pos_weight": spw}
    cats = [c for c in CATEGORICALS if c in Xtr.columns]
    dtr = lgb.Dataset(Xtr, ytr, categorical_feature=cats, free_raw_data=False)
    des = lgb.Dataset(Xes, yes, categorical_feature=cats, reference=dtr)
    return lgb.train(p, dtr, rounds, valid_sets=[des], callbacks=[lgb.early_stopping(es, verbose=False)])


def fit_lgbm_fixed(X, y, params, spw, rounds):
    p = {**LGB_BASE, **(params or {}), "scale_pos_weight": spw}
    cats = [c for c in CATEGORICALS if c in X.columns]
    return lgb.train(p, lgb.Dataset(X, y, categorical_feature=cats), rounds)


def margin(booster, X) -> np.ndarray:
    return booster.predict(X, raw_score=True, num_iteration=booster.best_iteration or None)


# --------------------------------------------------------------------------- calibration ---
def fit_platt(raw, y):
    lr = LogisticRegression(C=1e6, max_iter=1000).fit(np.asarray(raw).reshape(-1, 1), y)
    return float(lr.coef_[0, 0]), float(lr.intercept_[0])


def apply_platt(raw, ab):
    z = ab[0] * np.asarray(raw) + ab[1]
    return 1.0 / (1.0 + np.exp(-z))


# --------------------------------------------------------------------------- tuning --------
def tune(Xtr, ytr, n_trials=20, seed=0):
    """Optuna search with *expanding-window, time-ordered* CV (no shuffling, no future leakage)."""
    import optuna
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    n = len(Xtr)
    folds = [(int(n * a), int(n * b), int(n * c)) for a, b, c in [(0, .5, .65), (0, .65, .8), (0, .8, 1.0)]]
    ratio = (1 - ytr.mean()) / max(ytr.mean(), 1e-9)

    def objective(trial):
        params = dict(num_leaves=trial.suggest_int("num_leaves", 15, 127),
                      min_child_samples=trial.suggest_int("min_child_samples", 10, 200),
                      feature_fraction=trial.suggest_float("feature_fraction", 0.5, 1.0),
                      lambda_l2=trial.suggest_float("lambda_l2", 1e-2, 30, log=True),
                      learning_rate=0.08)
        spw = float(np.sqrt(ratio)) if trial.suggest_categorical("weight", ["none", "sqrt"]) == "sqrt" else 1.0
        scores = []
        for lo, mid, hi in folds:
            b = fit_lgbm(Xtr.iloc[lo:mid], ytr[lo:mid], Xtr.iloc[mid:hi], ytr[mid:hi], params, spw, rounds=400, es=30)
            scores.append(average_precision_score(ytr[mid:hi], margin(b, Xtr.iloc[mid:hi])))
        return float(np.mean(scores))

    st = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=seed))
    st.optimize(objective, n_trials=n_trials)
    best = dict(st.best_params)
    spw = float(np.sqrt(ratio)) if best.pop("weight") == "sqrt" else 1.0
    best["learning_rate"] = 0.05
    return best, spw, float(st.best_value)
