"""Synthetic card-transaction generator.

Purpose: let the whole pipeline run end to end without a Kaggle login, with *known* attack
patterns so error analysis ("which attack types do we miss?") is possible.

Legitimate behaviour: per-card spending level, preferred hours, 1-2 devices (some shared by a
household), occasional new phones and shopping sprees, rare large purchases.

Attack types:
  ato      account takeover: burst from a new device, higher amounts, often at night
  testing  card testing: many tiny amounts then one larger charge
  ring     fraud ring: a few devices reused across many stolen cards over days
  slow     "low and slow": few, near-normal amounts spread over hours. Only appears late in the
           timeline (drift), so the frozen model has never seen it.
8% of fraud labels are dropped (unreported chargebacks) to emulate label noise.
"""
import numpy as np
import pandas as pd

PRODUCTS = ["W", "C", "H", "R", "S"]
EMAILS = ["gmail.com", "yahoo.com", "outlook.com", "icloud.com", "proton.me", "other"]
DEVICE_TYPES = ["mobile", "desktop", "tablet"]


def generate(n_txn=150_000, n_cards=7000, days=120, fraud_rate=0.03, drift_start=0.82,
             seed=7) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    H = days * 86400
    n_fraud_gen = int(n_txn * fraud_rate / 0.92)
    n_base = int((n_txn - n_fraud_gen) / 1.10)

    # ---- card profiles ------------------------------------------------------------------
    w = rng.lognormal(0, 0.9, n_cards); w /= w.sum()
    mu = rng.normal(3.5, 0.6, n_cards)
    sig = rng.uniform(0.35, 0.75, n_cards)
    center = np.clip(rng.normal(14, 3.5, n_cards), 6, 22)
    pref = rng.choice(PRODUCTS, n_cards, p=[.55, .12, .13, .12, .08])
    email = rng.choice(EMAILS, n_cards, p=[.40, .15, .15, .10, .03, .17])
    dev = np.arange(n_cards * 2).reshape(n_cards, 2)
    share = rng.random(n_cards) < 0.06                     # households sharing a device
    partner = rng.integers(0, n_cards, n_cards)
    dev[share, 1] = dev[partner[share], 0]
    dtype_of = {int(d): t for d, t in zip(range(n_cards * 2),
                rng.choice(DEVICE_TYPES, n_cards * 2, p=[.60, .32, .08]))}

    # ---- legitimate traffic -------------------------------------------------------------
    cards = rng.choice(n_cards, n_base, p=w)
    hr = center[cards] + rng.normal(0, 3.5, n_base)
    rnd = rng.random(n_base) < 0.06
    hr[rnd] = rng.uniform(0, 24, rnd.sum())
    hr %= 24
    ts = (rng.integers(0, days, n_base) * 86400 + hr * 3600).astype(np.int64)
    la = rng.normal(mu[cards], sig[cards])
    la[rng.random(n_base) < 0.02] += np.log(rng.uniform(4, 12))      # rare large purchase
    la[ts > drift_start * H] += 0.10                                    # mild legit drift
    amount = np.round(np.exp(la), 2).clip(0.5)
    slot = (rng.random(n_base) < 0.2).astype(int)
    dev_ids = dev[cards, slot].astype(np.int64)
    newd = rng.random(n_base) < 0.03                                    # new phone / travel
    dev_ids[newd] = 10_000_000 + np.arange(newd.sum())
    for d in dev_ids[newd]:
        dtype_of[int(d)] = rng.choice(DEVICE_TYPES, p=[.7, .25, .05])
    prod = np.where(rng.random(n_base) < 0.8, pref[cards], rng.choice(PRODUCTS, n_base))
    base = pd.DataFrame({"ts": ts, "card": cards, "amount": amount, "dev": dev_ids,
                         "product": prod, "email_domain": email[cards]})

    # shopping sprees: legitimate bursts that look like velocity
    idx = np.flatnonzero(rng.random(n_base) < 0.04)
    k = rng.integers(1, 5, len(idx))
    rep = np.repeat(idx, k)
    gaps = rng.exponential(360, len(rep)).astype(int) + 30
    cs = np.cumsum(gaps)
    start = np.cumsum(k) - k
    offs = cs - np.repeat(cs[start] - gaps[start], k)
    spree = base.iloc[rep].copy()
    spree["ts"] = spree["ts"].to_numpy() + offs
    spree["amount"] = np.round(np.exp(rng.normal(mu[spree["card"]], sig[spree["card"]])), 2).clip(0.5)
    legit = pd.concat([base, spree], ignore_index=True)
    legit["attack"] = "legit"
    legit["is_fraud"] = 0

    # ---- fraud --------------------------------------------------------------------------
    rows = []
    fdev = [20_000_000]
    rdev = [30_000_000]
    vw = w ** 0.5; vw /= vw.sum()

    def new_fraud_device():
        fdev[0] += 1
        dtype_of[fdev[0]] = rng.choice(DEVICE_TYPES, p=[.4, .55, .05])
        return fdev[0]

    def emit(attack, t, c, a, d, p, em):
        if 0 <= t < H:
            rows.append((int(t), int(c), round(float(a), 2), int(d), p, em, attack))

    while len(rows) < n_fraud_gen:
        t0 = rng.uniform(0.01, 0.99) * H
        late = t0 > drift_start * H
        # event probabilities chosen so that *row* shares are balanced (rings/testing emit many rows)
        pr = [.30, .10, .05, .55] if late else [.69, .19, .12, 0.0]
        kind = rng.choice(["ato", "testing", "ring", "slow"], p=pr)
        c = rng.choice(n_cards, p=vw)
        tm = lambda: "other" if rng.random() < 0.25 else email[c]
        if kind == "ato":
            if rng.random() < 0.5:
                t0 = (t0 // 86400) * 86400 + rng.uniform(0, 5) * 3600
            n = 2 + rng.geometric(0.3)
            t = t0 + np.cumsum(rng.exponential(480, n))
            d = new_fraud_device()
            for ti in t:
                emit("ato", ti, c, np.exp(rng.normal(mu[c] + 1.1, 0.6)), d,
                     rng.choice(["C", "H", "R", "W"], p=[.35, .30, .15, .20]), tm())
        elif kind == "testing":
            n = rng.integers(8, 26)
            t = t0 + np.cumsum(rng.exponential(60, n))
            d = new_fraud_device()
            for i, ti in enumerate(t):
                a = rng.uniform(0.5, 5) if i < n - 1 else np.exp(rng.normal(mu[c] + 0.9, 0.4))
                emit("testing", ti, c, a, d, "C", "other" if rng.random() < 0.4 else email[c])
        elif kind == "ring":
            devs = []
            for _ in range(rng.integers(3, 6)):
                rdev[0] += 1
                dtype_of[rdev[0]] = rng.choice(DEVICE_TYPES, p=[.5, .45, .05])
                devs.append(rdev[0])
            dur = rng.uniform(1, 4) * 86400
            for _ in range(rng.integers(15, 50)):
                cc = rng.choice(n_cards, p=vw)
                emit("ring", t0 + rng.uniform(0, dur), cc, np.exp(rng.normal(mu[cc] + 0.6, 0.5)),
                     rng.choice(devs), rng.choice(["H", "R", "C"]),
                     "other" if rng.random() < 0.3 else email[cc])
        else:  # slow
            t0 = (t0 // 86400) * 86400 + rng.uniform(9, 19) * 3600
            n = rng.integers(2, 5)
            t = t0 + np.cumsum(rng.exponential(5 * 3600, n))
            d = new_fraud_device()
            for ti in t:
                emit("slow", ti, c, np.exp(rng.normal(mu[c] + 0.15, 0.4)), d, pref[c], email[c])

    f = pd.DataFrame(rows, columns=["ts", "card", "amount", "dev", "product", "email_domain", "attack"])
    f["is_fraud"] = (rng.random(len(f)) > 0.08).astype(int)             # label noise

    df = pd.concat([legit, f], ignore_index=True)
    df = df.sort_values("ts", kind="mergesort").reset_index(drop=True)
    df = df[df["ts"] < H].reset_index(drop=True)
    out = pd.DataFrame({
        "ts": df["ts"].astype("int64"),
        "card_id": "c" + df["card"].astype(str),
        "amount": df["amount"].astype(float),
        "device_id": "d" + df["dev"].astype(str),
        "product": df["product"],
        "email_domain": df["email_domain"],
        "device_type": [dtype_of[int(x)] for x in df["dev"]],
        "is_fraud": df["is_fraud"].astype(int),
        "attack": df["attack"],
    })
    out.insert(0, "txn_id", np.arange(len(out)))
    return out
