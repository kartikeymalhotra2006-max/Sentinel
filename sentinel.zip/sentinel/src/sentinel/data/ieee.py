"""Loader that maps the Kaggle IEEE-CIS Fraud Detection files to Sentinel's canonical schema.

Download train_transaction.csv and train_identity.csv from
https://www.kaggle.com/c/ieee-fraud-detection/data into one folder, then run
`python -m sentinel.pipeline --data ieee --ieee-dir <folder>`.

IEEE-CIS has no explicit card or device id, so (as is common in public solutions):
  card_id   = card1 + card2 + addr1 (proxy for a cardholder)
  device_id = DeviceInfo (a device *model*, not a unique device; missing for most rows)
Device-graph features are therefore weaker on this dataset than on real production data and
are NaN when DeviceInfo is missing. Document this in your README results.
"""
from pathlib import Path
import numpy as np
import pandas as pd


def to_canonical(tr: pd.DataFrame, idt: pd.DataFrame) -> pd.DataFrame:
    d = tr.merge(idt, on="TransactionID", how="left")
    # card2 / addr1 are sometimes missing: encode that as "na" instead of letting concatenation produce NaN,
    # which would silently merge every such row into one giant fake card.
    part = lambda c: d[c].round().astype("Int64").astype("string").fillna("na")
    card = part("card1") + "_" + part("card2") + "_" + part("addr1")
    out = pd.DataFrame({
        "txn_id": d["TransactionID"].to_numpy(),
        "ts": d["TransactionDT"].astype("int64").to_numpy(),
        "card_id": card.to_numpy(),
        "amount": d["TransactionAmt"].astype(float).to_numpy(),
        "device_id": d["DeviceInfo"].to_numpy(),
        "product": d["ProductCD"].to_numpy(),
        "email_domain": d["P_emaildomain"].to_numpy(),
        "device_type": d["DeviceType"].to_numpy(),
        "is_fraud": d["isFraud"].astype(int).to_numpy(),
    })
    out["attack"] = np.where(out["is_fraud"] == 1, "fraud", "legit")
    return out.sort_values(["ts", "txn_id"], kind="mergesort").reset_index(drop=True)


def load_ieee(folder: str) -> pd.DataFrame:
    p = Path(folder)
    tr = pd.read_csv(p / "train_transaction.csv",
                     usecols=["TransactionID", "isFraud", "TransactionDT", "TransactionAmt",
                              "ProductCD", "card1", "card2", "addr1", "P_emaildomain"])
    idt = pd.read_csv(p / "train_identity.csv", usecols=["TransactionID", "DeviceType", "DeviceInfo"])
    return to_canonical(tr, idt)
