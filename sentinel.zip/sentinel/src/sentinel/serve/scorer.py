"""Loads the model bundle and turns a feature dict into risk, decision and reason codes."""
import math
from pathlib import Path

import joblib
import lightgbm as lgb
import numpy as np

from ..config import ANOMALY_FEATURES, FEATURES
from ..explain import reason_codes


class Scorer:
    def __init__(self, bundle_path=None, bundle=None):
        b = bundle if bundle is not None else joblib.load(Path(bundle_path))
        self.bundle = b
        self.version = b["version"]
        self.vocab = b["vocab"]
        self.booster = lgb.Booster(model_str=b["model_str"])
        self.names = b["feature_names"]
        self.platt = b["platt"]
        self.t_review = b["thresholds"]["review"]
        self.t_decline = b["thresholds"]["decline"]
        self.use_anomaly = b["use_anomaly"]
        self.iso = b["anomaly"]

    def vector(self, f: dict) -> list:
        vec = [f[k] for k in FEATURES]
        if self.use_anomaly:
            a = -self.iso.decision_function(np.array([[f[k] for k in ANOMALY_FEATURES]], dtype=float))[0]
            vec.append(float(a))
        return vec

    def decide(self, risk: float) -> str:
        return "decline" if risk >= self.t_decline else "review" if risk >= self.t_review else "approve"

    def score(self, f: dict, explain: bool = True) -> dict:
        vec = self.vector(f)
        arr = np.asarray([vec], dtype=float)
        if explain:
            contrib = self.booster.predict(arr, pred_contrib=True)[0]
            m = float(contrib.sum())
        else:
            contrib, m = None, float(self.booster.predict(arr, raw_score=True)[0])
        risk = 1.0 / (1.0 + math.exp(-(self.platt[0] * m + self.platt[1])))
        decision = self.decide(risk)
        reasons = reason_codes(contrib, self.names, vec, vocab=self.vocab) if (explain and decision != "approve") else []
        return {"risk": risk, "decision": decision, "reasons": reasons, "vector": vec}
