"""Online feature computation. MUST stay numerically identical to sentinel.features.build_features.

Usage per transaction:   feats = fz.features(txn)    # reads state only
                         fz.commit(txn)               # then appends this txn to the state
so a transaction is never part of its own history.
"""
import math

from ..config import FEATURES, WINDOWS

_NAN = float("nan")
MAX_DEVICES_PER_CARD = 200
MAX_CARDS_PER_DEVICE = 5000


def _new_card(): return {"n": 0, "s": 0.0, "ss": 0.0, "mx": None, "last_ts": None, "recent": [], "devs": []}
def _new_dev(): return {"cards": [], "recent": []}


class OnlineFeaturizer:
    def __init__(self, store, vocab: dict):
        self.store, self.vocab = store, vocab
        self._maps = {c: {v: i for i, v in enumerate(vs)} for c, vs in vocab.items()}

    def _cat(self, col, val):
        return float(self._maps[col].get(str(val), -1)) if val is not None else -1.0

    def features(self, txn: dict) -> dict:
        t, a = int(txn["ts"]), float(txn["amount"])
        card = self.store.get_card(txn["card_id"]) or _new_card()
        did = txn.get("device_id")
        dev = (self.store.get_device(did) or _new_dev()) if did is not None else None

        f = {}
        n = card["n"]
        for name, w in WINDOWS.items():
            rec = [x for x in card["recent"] if x[0] >= t - w]
            f[f"n_{name}"] = float(len(rec))
            if name == "24h":
                f["sum_24h"] = float(sum(x[1] for x in rec))
        f["n_prior"] = float(n)
        if n > 0:
            mean = card["s"] / n
            std = math.sqrt(max(card["ss"] / n - mean ** 2, 0.0))
            f["sec_since_last"] = float(t - card["last_ts"])
            f["amt_ratio_mean"] = a / mean
            f["amt_z"] = (a - mean) / (std + 1.0)
            f["amt_over_max"] = a / card["mx"]
        else:
            f["sec_since_last"] = f["amt_ratio_mean"] = f["amt_z"] = f["amt_over_max"] = _NAN
        f["log_amt"] = math.log1p(a)

        if dev is not None:
            f["pair_new"] = 0.0 if did in card["devs"] else 1.0
            f["device_card_count"] = float(len(dev["cards"]))
            f["card_device_count"] = float(len(card["devs"]))
            f["dev_n_1h"] = float(sum(1 for x in dev["recent"] if x >= t - WINDOWS["1h"]))
            f["dev_n_24h"] = float(sum(1 for x in dev["recent"] if x >= t - WINDOWS["24h"]))
        else:
            for k in ("pair_new", "device_card_count", "card_device_count", "dev_n_1h", "dev_n_24h"):
                f[k] = _NAN
        f["hour"] = float((t // 3600) % 24)
        f["dow"] = float((t // 86400) % 7)
        for c in ("product", "email_domain", "device_type"):
            f[c] = self._cat(c, txn.get(c))
        f["_out_of_order"] = card["last_ts"] is not None and t < card["last_ts"]
        return f

    def commit(self, txn: dict) -> None:
        t, a, cid, did = int(txn["ts"]), float(txn["amount"]), txn["card_id"], txn.get("device_id")
        card = self.store.get_card(cid) or _new_card()
        card["n"] += 1; card["s"] += a; card["ss"] += a * a
        card["mx"] = a if card["mx"] is None else max(card["mx"], a)
        card["last_ts"] = t if card["last_ts"] is None else max(card["last_ts"], t)
        card["recent"] = [x for x in card["recent"] if x[0] >= t - WINDOWS["7d"]] + [[t, a]]
        if did is not None:
            dev = self.store.get_device(did) or _new_dev()
            if did not in card["devs"] and len(card["devs"]) < MAX_DEVICES_PER_CARD:
                card["devs"].append(did)
            if cid not in dev["cards"] and len(dev["cards"]) < MAX_CARDS_PER_DEVICE:
                dev["cards"].append(cid)
            dev["recent"] = [x for x in dev["recent"] if x >= t - WINDOWS["24h"]] + [t]
            self.store.put_device(did, dev)
        self.store.put_card(cid, card)


def feature_vector(f: dict) -> list:
    return [f[k] for k in FEATURES]
