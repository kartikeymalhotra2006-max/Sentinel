"""FastAPI scoring service.

    SENTINEL_BUNDLE=artifacts/bundle.joblib uvicorn sentinel.serve.app:app
    (set REDIS_URL to keep per-card state in Redis instead of process memory)

POST /score   score one transaction, return risk, decision, top reason codes, latency
GET  /health  liveness + model version        GET /model  metadata and thresholds
GET  /drift   PSI of recent live traffic vs training reference
"""
import os
import time
from collections import OrderedDict, deque
from contextlib import asynccontextmanager
from typing import List, Optional

import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

from ..config import FEATURE_FAMILIES, FEATURES
from ..drift import psi
from .online import OnlineFeaturizer
from .scorer import Scorer
from .state import InMemoryStore, RedisStore

# hour/dow are cyclical: PSI on short live windows is meaningless, so they are excluded from drift alerts.
# n_prior / *_count features are cumulative (grow with history by construction) so PSI on them always "drifts".
_STRUCTURAL = {"n_prior", "card_device_count", "device_card_count"}
DRIFT_FEATURES = [f for f in FEATURES if f not in FEATURE_FAMILIES["time"] and f not in _STRUCTURAL]


class Txn(BaseModel):
    txn_id: Optional[str] = None
    ts: int = Field(ge=0, description="Unix seconds (or any monotonically increasing seconds clock)")
    card_id: str = Field(min_length=1)
    amount: float = Field(gt=0, le=10_000_000)
    device_id: Optional[str] = None
    product: Optional[str] = None
    email_domain: Optional[str] = None
    device_type: Optional[str] = None


class Reason(BaseModel):
    feature: str
    impact: float
    detail: str


class IngestRequest(BaseModel):
    txns: List[Txn] = Field(max_length=5000)


class ScoreResponse(BaseModel):
    txn_id: Optional[str]
    risk: float
    decision: str
    reasons: List[Reason]
    model_version: str
    latency_ms: float
    out_of_order: bool = False
    replayed: bool = False


def create_app(bundle_path: Optional[str] = None, store=None) -> FastAPI:
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        path = bundle_path or os.environ.get("SENTINEL_BUNDLE", "artifacts/bundle.joblib")
        app.state.scorer = Scorer(path)
        if store is not None:
            st = store
        elif os.environ.get("REDIS_URL"):
            import redis
            st = RedisStore(redis.Redis.from_url(os.environ["REDIS_URL"]))
        else:
            st = InMemoryStore()
        app.state.featurizer = OnlineFeaturizer(st, app.state.scorer.vocab)
        app.state.seen = OrderedDict()                 # txn_id -> response (idempotency, bounded)
        app.state.recent = deque(maxlen=5000)          # (feature vector, risk) for /drift
        app.state.counts = {"approve": 0, "review": 0, "decline": 0}
        yield

    app = FastAPI(title="Sentinel fraud scoring", version="1.0.0", lifespan=lifespan)

    @app.get("/health")
    def health():
        return {"status": "ok", "model_version": app.state.scorer.version}

    @app.get("/model")
    def model():
        s = app.state.scorer
        return {"model_version": s.version, "features": s.names, "thresholds": {"review": s.t_review, "decline": s.t_decline},
                "cost_model": s.bundle["cost_model"], "metadata": s.bundle["metadata"], "decisions_served": app.state.counts}

    @app.post("/score", response_model=ScoreResponse)
    def score(txn: Txn, commit: bool = Query(True, description="append txn to card/device history after scoring")):
        t0 = time.perf_counter()
        if txn.txn_id and txn.txn_id in app.state.seen:   # idempotent retry: never double-count history
            r = dict(app.state.seen[txn.txn_id]); r["replayed"] = True
            return r
        d = txn.model_dump()
        fz, sc = app.state.featurizer, app.state.scorer
        try:
            f = fz.features(d)
            res = sc.score(f)
        except Exception as e:                            # fail loudly; callers decide fail-open/closed
            raise HTTPException(status_code=500, detail=f"scoring failed: {e}")
        if commit:
            fz.commit(d)
        app.state.recent.append((res["vector"][:len(FEATURES)], res["risk"]))
        app.state.counts[res["decision"]] += 1
        out = {"txn_id": txn.txn_id, "risk": round(res["risk"], 6), "decision": res["decision"], "reasons": res["reasons"],
               "model_version": sc.version, "latency_ms": round((time.perf_counter() - t0) * 1000, 2),
               "out_of_order": bool(f["_out_of_order"]), "replayed": False}
        if txn.txn_id:
            app.state.seen[txn.txn_id] = out
            if len(app.state.seen) > 100_000:
                app.state.seen.popitem(last=False)
        return out

    @app.post("/ingest")
    def ingest(req: IngestRequest):
        """Append historical transactions (arrival order) to card/device state WITHOUT scoring them or
        counting them in drift stats. For cold-start backfill and replays."""
        for t in req.txns:
            app.state.featurizer.commit(t.model_dump())
        return {"ingested": len(req.txns)}

    @app.get("/drift")
    def drift(min_samples: int = 200):
        rec = app.state.recent
        if len(rec) < min_samples:
            return {"status": "insufficient_data", "samples": len(rec), "needed": min_samples}
        ref = app.state.scorer.bundle["reference"]
        cur = pd.DataFrame([r[0] for r in rec], columns=FEATURES)
        fp = {c: psi(ref["features"][c], cur[c]) for c in DRIFT_FEATURES}
        sp = psi(ref["scores"], np.array([r[1] for r in rec]))
        top = dict(sorted(fp.items(), key=lambda kv: -kv[1])[:5])
        return {"status": "ok", "samples": len(rec), "score_psi": sp, "top_feature_psi": top,
                "alert": bool(sp > 0.2 or max(fp.values()) > 0.25),
                "features_checked": len(DRIFT_FEATURES),
                "note": "Only meaningful once card state is warm (cold-start cards score higher). PSI <0.1 stable, 0.1-0.25 moderate, >0.25 major. PSI cannot detect attacks that evade the model; track recall with delayed labels too."}

    return app


app = create_app()
