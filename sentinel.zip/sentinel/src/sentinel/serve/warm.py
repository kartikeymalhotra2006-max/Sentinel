"""Helpers to replay historical transactions into the online state (cold-start / demos)."""
import math

import pandas as pd


def row_to_txn(r: dict) -> dict:
    t = {}
    for k in ("ts", "card_id", "amount", "device_id", "product", "email_domain", "device_type"):
        v = r.get(k)
        t[k] = None if (v is None or (isinstance(v, float) and math.isnan(v))) else v
    t["ts"], t["amount"] = int(t["ts"]), float(t["amount"])
    return t


def warm_store(featurizer, df: pd.DataFrame) -> int:
    n = 0
    for r in df.to_dict("records"):
        featurizer.commit(row_to_txn(r))
        n += 1
    return n
