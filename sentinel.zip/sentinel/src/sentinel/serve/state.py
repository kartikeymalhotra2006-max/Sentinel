"""Per-card and per-device state used to compute features online.

InMemoryStore is used for tests/demos; RedisStore for deployment. Values are small JSON blobs.
Known limitation: read-modify-write is not atomic across several API workers writing the same
card at the same instant. For production use a Lua script / Redis transaction or route all
events for one card to the same worker (e.g. Kafka partition by card_id).
"""
import json
from typing import Optional


class StateStore:
    def get_card(self, card_id: str) -> Optional[dict]: raise NotImplementedError
    def put_card(self, card_id: str, state: dict) -> None: raise NotImplementedError
    def get_device(self, device_id: str) -> Optional[dict]: raise NotImplementedError
    def put_device(self, device_id: str, state: dict) -> None: raise NotImplementedError


class InMemoryStore(StateStore):
    def __init__(self):
        self.cards, self.devices = {}, {}
    def get_card(self, card_id): return self.cards.get(card_id)
    def put_card(self, card_id, state): self.cards[card_id] = state
    def get_device(self, device_id): return self.devices.get(device_id)
    def put_device(self, device_id, state): self.devices[device_id] = state


class RedisStore(StateStore):
    TTL = 8 * 86400   # state older than the longest feature window is irrelevant

    def __init__(self, client):
        self.r = client
    def _get(self, k):
        v = self.r.get(k)
        return json.loads(v) if v else None
    def _put(self, k, state): self.r.set(k, json.dumps(state), ex=self.TTL)
    def get_card(self, card_id): return self._get(f"card:{card_id}")
    def put_card(self, card_id, state): self._put(f"card:{card_id}", state)
    def get_device(self, device_id): return self._get(f"dev:{device_id}")
    def put_device(self, device_id, state): self._put(f"dev:{device_id}", state)
