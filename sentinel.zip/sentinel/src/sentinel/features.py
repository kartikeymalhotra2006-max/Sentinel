"""Leakage-safe feature engineering, batch version.

Every feature for transaction i is computed from transactions that arrived strictly *before* i
(earlier position in the time-sorted stream). tests/test_leakage.py proves this by truncating
the future, and tests/test_parity.py proves the online featurizer (serve/online.py) produces the
same values as this batch code, which is what prevents training/serving skew.
"""
import numpy as np
import pandas as pd

from .config import CATEGORICALS, FEATURES, WINDOWS

_BIG = np.int64(1) << 32   # larger than max(ts) + longest window, so groups never overlap


def _sorted_view(groups: np.ndarray, ts: np.ndarray):
    n = len(groups)
    order = np.lexsort((np.arange(n), ts, groups))      # group, then time, then arrival order
    return order, groups[order].astype(np.int64), ts[order].astype(np.int64)


def _unsort(values: np.ndarray, order: np.ndarray) -> np.ndarray:
    out = np.empty_like(values)
    out[order] = values
    return out


def _window_stats(groups, ts, amount, windows):
    """For each row: count and amount-sum of *earlier* rows of the same group within each window."""
    order, g, t = _sorted_view(groups, ts)
    a = amount[order].astype(float)
    key = g * _BIG + t
    csum = np.concatenate([[0.0], np.cumsum(a)])
    pos = np.arange(len(g))
    out = {}
    for name, w in windows.items():
        left = np.searchsorted(key, g * _BIG + (t - w), side="left")
        out[f"cnt_{name}"] = _unsort((pos - left).astype(float), order)
        out[f"sum_{name}"] = _unsort(csum[pos] - csum[left], order)
    return out


def fit_vocab(df: pd.DataFrame, min_count: int = 20) -> dict:
    """Categorical vocabularies learned on training rows only. Unknown/rare values map to -1."""
    vocab = {}
    for c in CATEGORICALS:
        vc = df[c].dropna().astype(str).value_counts()
        vocab[c] = sorted(vc[vc >= min_count].index.tolist())
    return vocab


def encode_categoricals(df: pd.DataFrame, vocab: dict) -> pd.DataFrame:
    out = pd.DataFrame(index=df.index)
    for c in CATEGORICALS:
        m = {v: i for i, v in enumerate(vocab[c])}
        out[c] = df[c].astype(object).map(lambda x: m.get(str(x), -1) if pd.notna(x) else -1).astype(int)
    return out


def build_features(df: pd.DataFrame, vocab: dict) -> pd.DataFrame:
    """df must be in arrival (time) order with the canonical schema. Returns FEATURES columns."""
    ts = df["ts"].to_numpy(dtype=np.int64)
    if len(ts) > 1 and (np.diff(ts) < 0).any():
        raise ValueError("df must be sorted by ts (arrival order)")
    if df["card_id"].isna().any():
        raise ValueError("card_id contains nulls; they would be merged into a single fake card")
    amt = df["amount"].to_numpy(dtype=float)
    n = len(df)
    cards = pd.factorize(df["card_id"])[0]
    F = pd.DataFrame(index=df.index)

    # ---- card velocity & amount behaviour ---------------------------------------------------
    ws = _window_stats(cards, ts, amt, WINDOWS)
    F["n_1h"], F["n_24h"], F["n_7d"] = ws["cnt_1h"], ws["cnt_24h"], ws["cnt_7d"]
    F["sum_24h"] = ws["sum_24h"]

    order, g, t = _sorted_view(cards, ts)
    a = amt[order]
    pos = np.arange(n)
    gstart = np.searchsorted(g, g, side="left")
    n_prior = (pos - gstart).astype(float)
    # per-group running sums (same summation order as the online featurizer => no cancellation error)
    sa = pd.Series(a)
    s_prior = sa.groupby(g).cumsum().groupby(g).shift(1).fillna(0.0).to_numpy()
    ss_prior = (sa * sa).groupby(g).cumsum().groupby(g).shift(1).fillna(0.0).to_numpy()
    with np.errstate(invalid="ignore", divide="ignore"):
        mean = np.where(n_prior > 0, s_prior / n_prior, np.nan)
        var = np.where(n_prior > 0, ss_prior / n_prior - mean ** 2, np.nan)
    std = np.sqrt(np.clip(var, 0, None))
    cm = pd.Series(a).groupby(g).cummax()
    prior_max = cm.groupby(g).shift(1).to_numpy()
    prev_t = np.r_[np.nan, t[:-1].astype(float)]
    prev_t[np.r_[True, g[1:] != g[:-1]]] = np.nan

    F["n_prior"] = _unsort(n_prior, order)
    mean_u, std_u, max_u = _unsort(mean, order), _unsort(std, order), _unsort(prior_max, order)
    F["sec_since_last"] = ts - _unsort(prev_t, order)
    F["log_amt"] = np.log1p(amt)
    F["amt_ratio_mean"] = amt / mean_u
    F["amt_z"] = (amt - mean_u) / (std_u + 1.0)
    F["amt_over_max"] = amt / max_u

    # ---- device graph ---------------------------------------------------------------------
    dev = df["device_id"]
    has = dev.notna().to_numpy()
    for c in ["pair_new", "device_card_count", "card_device_count", "dev_n_1h", "dev_n_24h"]:
        F[c] = np.nan
    if has.any():
        idx = np.flatnonzero(has)
        d_codes = pd.factorize(dev.iloc[idx])[0]
        c_codes = cards[idx]
        pair = pd.Series(d_codes.astype(np.int64) * (c_codes.max() + 1) + c_codes)
        first = (~pair.duplicated(keep="first")).astype(int).to_numpy()
        fs = pd.Series(first)
        dcc = fs.groupby(d_codes).cumsum().to_numpy() - first        # distinct cards on device before
        cdc = fs.groupby(c_codes).cumsum().to_numpy() - first        # distinct devices on card before
        dws = _window_stats(d_codes, ts[idx], amt[idx], {"1h": WINDOWS["1h"], "24h": WINDOWS["24h"]})
        F.loc[F.index[idx], "pair_new"] = first.astype(float)
        F.loc[F.index[idx], "device_card_count"] = dcc.astype(float)
        F.loc[F.index[idx], "card_device_count"] = cdc.astype(float)
        F.loc[F.index[idx], "dev_n_1h"] = dws["cnt_1h"]
        F.loc[F.index[idx], "dev_n_24h"] = dws["cnt_24h"]

    # ---- time -----------------------------------------------------------------------------
    F["hour"] = ((ts // 3600) % 24).astype(float)
    F["dow"] = ((ts // 86400) % 7).astype(float)

    F = pd.concat([F, encode_categoricals(df, vocab)], axis=1)
    return F[FEATURES]
