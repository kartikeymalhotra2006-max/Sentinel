"""Central configuration: schema, feature families, split fractions and the cost model."""
from dataclasses import dataclass

# Canonical transaction schema used everywhere (batch training and online serving).
RAW_COLUMNS = ["ts", "card_id", "amount", "device_id", "product", "email_domain", "device_type"]
TARGET = "is_fraud"
CATEGORICALS = ["product", "email_domain", "device_type"]

# Feature families (used for documentation and the ablation study).
FEATURE_FAMILIES = {
    "amount": ["log_amt", "amt_ratio_mean", "amt_z", "amt_over_max"],
    "velocity": ["n_1h", "n_24h", "n_7d", "sum_24h", "sec_since_last", "n_prior"],
    "device_graph": ["pair_new", "device_card_count", "card_device_count", "dev_n_1h", "dev_n_24h"],
    "time": ["hour", "dow"],
    "categorical": ["product", "email_domain", "device_type"],
}
NUMERIC_FEATURES = [f for fam, fs in FEATURE_FAMILIES.items() if fam != "categorical" for f in fs]
FEATURES = NUMERIC_FEATURES + CATEGORICALS

# Features fed to the unsupervised anomaly detector (numeric behaviour only).
ANOMALY_FEATURES = [f for f in NUMERIC_FEATURES if f not in FEATURE_FAMILIES["time"]]

# Chronological split. Never shuffled: the model is always evaluated on the future.
SPLITS = {"train": 0.55, "es": 0.10, "calib": 0.10, "val": 0.10, "test": 0.15}

WINDOWS = {"1h": 3600, "24h": 86400, "7d": 7 * 86400}


@dataclass(frozen=True)
class CostModel:
    """Business assumptions behind the decision threshold. All values are configurable."""
    decline_cost: float = 15.0        # lost margin + churn risk when a good customer is declined
    review_cost: float = 3.0          # analyst time per manually reviewed transaction
    review_catch_rate: float = 0.85   # share of fraud an analyst catches in review

    def as_dict(self):
        return {"decline_cost": self.decline_cost, "review_cost": self.review_cost,
                "review_catch_rate": self.review_catch_rate}
