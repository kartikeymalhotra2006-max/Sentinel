"""Per-transaction explanations from LightGBM's exact TreeSHAP contributions (pred_contrib)."""
import numpy as np

REASON_TEXT = {
    "n_1h": lambda v: f"{v:.0f} earlier transactions on this card in the last hour",
    "n_24h": lambda v: f"{v:.0f} earlier transactions on this card in 24 hours",
    "n_7d": lambda v: f"{v:.0f} earlier transactions on this card in 7 days",
    "sum_24h": lambda v: f"${v:,.0f} already spent on this card in 24 hours",
    "sec_since_last": lambda v: f"only {v/60:.0f} min since the previous transaction" if v < 7200 else f"{v/3600:.1f} h since previous transaction",
    "n_prior": lambda v: f"card has only {v:.0f} prior transactions" if v < 5 else f"card history length {v:.0f}",
    "log_amt": lambda v: f"transaction amount ${np.expm1(v):,.2f}",
    "amt_ratio_mean": lambda v: f"amount is {v:.1f}x this card's average",
    "amt_z": lambda v: f"amount is {v:.1f} std devs from this card's norm",
    "amt_over_max": lambda v: f"amount is {v:.1f}x the card's largest purchase so far",
    "pair_new": lambda v: "first time this card is seen on this device" if v >= 0.5 else "card already used on this device",
    "device_card_count": lambda v: f"device has been used with {v:.0f} other cards",
    "card_device_count": lambda v: f"card has used {v:.0f} distinct devices",
    "dev_n_1h": lambda v: f"{v:.0f} transactions from this device in the last hour",
    "dev_n_24h": lambda v: f"{v:.0f} transactions from this device in 24 hours",
    "hour": lambda v: f"unusual time of day ({v:.0f}:00)",
    "dow": lambda v: "day-of-week pattern",
    "product": lambda v: "product category",
    "email_domain": lambda v: "purchaser email domain",
    "device_type": lambda v: "device type",
    "anomaly_score": lambda v: "overall behaviour is statistically unusual (isolation forest)",
}


def contributions(booster, X):
    """Exact TreeSHAP values in log-odds; last column is the bias term."""
    return booster.predict(np.asarray(X, dtype=float), pred_contrib=True,
                           num_iteration=booster.best_iteration or None)


_HISTORY = {"sec_since_last", "amt_ratio_mean", "amt_z", "amt_over_max"}
_DEVICE = {"pair_new", "device_card_count", "card_device_count", "dev_n_1h", "dev_n_24h"}
_CAT_LABEL = {"product": "product code", "email_domain": "email domain", "device_type": "device type"}


def reason_codes(contrib_row, feature_names, values, k=3, min_contrib=0.05, vocab=None):
    """Top-k features pushing the score *towards fraud*, as analyst-readable text."""
    c = np.asarray(contrib_row)[:-1]
    out = []
    for i in np.argsort(-c)[:k]:
        if c[i] < min_contrib:
            break
        name, v = feature_names[i], values[i]
        if name in _CAT_LABEL:
            lst = (vocab or {}).get(name, [])
            label = lst[int(v)] if v == v and 0 <= int(v) < len(lst) else "unseen/rare value"
            txt = f"{_CAT_LABEL[name]} '{label}' is associated with higher fraud"
        elif v != v:
            txt = ("no prior history for this card (first transaction seen)" if name in _HISTORY else
                   "device not provided" if name in _DEVICE else f"{name} unavailable")
        else:
            txt = REASON_TEXT.get(name, lambda _: name)(v)
        out.append({"feature": name, "impact": round(float(c[i]), 3), "detail": txt})
    return out
