"""Sentinel: cost-aware, real-time card fraud detection."""
__version__ = "1.0.0"
