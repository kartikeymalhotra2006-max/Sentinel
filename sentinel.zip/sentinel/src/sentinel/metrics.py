"""Evaluation metrics, the 3-band cost model and cost-optimal threshold search."""
import numpy as np
from sklearn.metrics import average_precision_score, roc_auc_score, roc_curve

from .config import CostModel


def recall_at_fpr(y, s, fpr_target=0.01) -> float:
    fpr, tpr, _ = roc_curve(y, s)
    ok = fpr <= fpr_target
    return float(tpr[ok].max()) if ok.any() else 0.0


def ece(y, p, bins=10) -> float:
    """Expected calibration error with equal-mass bins."""
    y, p = np.asarray(y), np.asarray(p)
    edges = np.unique(np.quantile(p, np.linspace(0, 1, bins + 1)))
    idx = np.clip(np.searchsorted(edges, p, side="right") - 1, 0, len(edges) - 2)
    tot = 0.0
    for b in range(len(edges) - 1):
        m = idx == b
        if m.any():
            tot += m.mean() * abs(p[m].mean() - y[m].mean())
    return float(tot)


def ranking_metrics(y, s) -> dict:
    return {"pr_auc": float(average_precision_score(y, s)), "roc_auc": float(roc_auc_score(y, s)),
            "recall_at_1pct_fpr": recall_at_fpr(y, s, 0.01)}


def cluster_bootstrap_ap(y, s, groups, n_boot=200, seed=0):
    """95% CI for PR-AUC, resampling whole cards (fraud arrives in correlated bursts)."""
    rng = np.random.default_rng(seed)
    y, s = np.asarray(y), np.asarray(s)
    codes, _ = __import__("pandas").factorize(groups)
    order = np.argsort(codes, kind="stable")
    bounds = np.r_[0, np.cumsum(np.bincount(codes))]
    ng = len(bounds) - 1
    vals = []
    for _ in range(n_boot):
        pick = rng.integers(0, ng, ng)
        idx = np.concatenate([order[bounds[g]:bounds[g + 1]] for g in pick])
        if y[idx].sum() > 0:
            vals.append(average_precision_score(y[idx], s[idx]))
    return float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))


def policy_cost(score, y, amount, t_rev, t_dec, cm: CostModel) -> dict:
    """Approve below t_rev, send to manual review in [t_rev, t_dec), decline at >= t_dec."""
    score, y, amount = map(np.asarray, (score, y, amount))
    decline = score >= t_dec
    review = (score >= t_rev) & ~decline
    approve = ~(score >= t_rev)
    fraud = y == 1
    missed = amount[fraud & approve].sum() + (1 - cm.review_catch_rate) * amount[fraud & review].sum()
    fp = cm.decline_cost * ((~fraud) & decline).sum()
    rv = cm.review_cost * review.sum()
    return {"total": float(missed + fp + rv), "missed_fraud_loss": float(missed), "false_decline_cost": float(fp),
            "review_cost": float(rv), "n_decline": int(decline.sum()), "n_review": int(review.sum()),
            "fraud_amount_stopped": float(amount[fraud & decline].sum() + cm.review_catch_rate * amount[fraud & review].sum()),
            "fraud_recall_flagged": float((fraud & ~approve).sum() / max(fraud.sum(), 1)),
            "false_positive_rate_flagged": float(((~fraud) & ~approve).sum() / max((~fraud).sum(), 1))}


def approve_all_cost(y, amount) -> float:
    return float(np.asarray(amount)[np.asarray(y) == 1].sum())


def optimise_thresholds(score, y, amount, cm: CostModel, k=400):
    """Exhaustive search over (t_review <= t_decline) pairs on candidate score quantiles."""
    score, y, amount = map(np.asarray, (score, y, amount))
    o = np.argsort(score, kind="stable")
    s, yy, aa = score[o], y[o], amount[o]
    F = np.r_[0.0, np.cumsum(np.where(yy == 1, aa, 0.0))]        # prefix fraud $
    L = np.r_[0.0, np.cumsum(yy == 0)]                           # prefix legit count
    cand = np.unique(np.r_[np.quantile(s, np.linspace(0.30, 0.99995, k)), np.inf])
    pos = np.searchsorted(s, cand, side="left")
    ia, ib = pos[:, None], pos[None, :]
    cost = (F[ia] + (1 - cm.review_catch_rate) * (F[ib] - F[ia]) + cm.review_cost * (ib - ia)
            + cm.decline_cost * (L[-1] - L[ib]))
    cost = np.where(ia <= ib, cost, np.inf)
    i, j = np.unravel_index(np.argmin(cost), cost.shape)
    return _midpoint(s, cand[i]), _midpoint(s, cand[j])


def _midpoint(sorted_scores, t):
    """Move a threshold into the gap between adjacent distinct scores. Many rows can share an identical
    score (e.g. cold-start cards); a threshold sitting exactly on such a value would flip decisions on
    1e-16 float noise between the batch and online code paths. The partition of the data is unchanged."""
    if not np.isfinite(t):
        return float(t)
    hi = np.searchsorted(sorted_scores, t, side="left")           # first score >= t
    if hi == len(sorted_scores):
        return float(t)
    if hi == 0:                                                   # t at/below the minimum score: "flag everything"
        lo = float(sorted_scores[0])
        return lo - max(1e-9, 1e-6 * abs(lo))
    lo_val, hi_val = sorted_scores[hi - 1], sorted_scores[hi]
    return float((lo_val + hi_val) / 2.0) if lo_val < hi_val else float(t)
